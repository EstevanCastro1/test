import { useQuery } from '@apollo/client'
import { clientDirectusSystem } from '@components/templates/Providers'
import { GET_USER } from '@utils'

const useRole = () => {
  const { data: dataUser, loading: loadingUser } = useQuery(GET_USER, {
    client: clientDirectusSystem,
  })

  const role = dataUser?.users_me.role.name
  const name =
    `${dataUser?.users_me.first_name} ${dataUser?.users_me.last_name}`.trim()

  return { role, name, loadingUser }
}

export default useRole
