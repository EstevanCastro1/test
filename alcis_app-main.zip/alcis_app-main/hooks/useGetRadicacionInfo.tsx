import { useQuery } from '@apollo/client'
import { useRadicacionContext } from '@context/RadicacionContext'
import { RadicacionDirectus, UploadedFile } from '@interfaces/commons'
import { GET_RADICACION_BY_ID, USER_BASIC_INFO } from '@utils'
import { RIESGOS } from '@utils/constants'
import { UUID } from 'crypto'
import moment from 'moment'
import { useEffect } from 'react'

const useGetRadicacionInfo = (
  id: UUID | undefined,
  idPaciente?: UUID | undefined,
) => {
  const { tableRadicaciones } = useRadicacionContext()

  const {
    data,
    loading: loadingRadicacion,
    refetch,
  } = useQuery(GET_RADICACION_BY_ID, {
    variables: { id },
  })

  const { data: PacienteData } = useQuery(USER_BASIC_INFO, {
    variables: { id: idPaciente },
  })

  const paciente = PacienteData?.paciente[0]

  const dataRadicacion = data?.radicacion_by_id as RadicacionDirectus
  const riesgo = RIESGOS.find((r) => r.code === dataRadicacion?.riesgo)
  const diagnostico = dataRadicacion?.radicacion_diagnostico?.map((d) => ({
    id: d.diagnostico_id.id,
    codigo: d.diagnostico_id.codigo,
    descripcion: d.diagnostico_id.descripcion,
  }))
  const cup = dataRadicacion?.radicacion_cup?.map((c) => ({
    id: c.cup_id?.id,
    codigo: c.cup_id?.codigo,
    descripcion: c.cup_id?.descripcion,
    resoluciones: c.cup_id?.resoluciones,
    no_tr2: c.cup_id?.no_tr2,
  }))
  const especialidad = {
    nombre: dataRadicacion?.radicacion_especialidad?.nombre,
    id: dataRadicacion?.radicacion_especialidad?.id,
  }
  const medico_especialista = dataRadicacion?.radicacion_medico
  const observaciones = dataRadicacion?.observacion_radicado

  const trabajoSocialCirugia = dataRadicacion?.trabajo_social_cirugia_ejecutada
  const trabajoSocialFecha = dataRadicacion?.trabajo_social_fecha_cirugia
    ? moment(dataRadicacion?.trabajo_social_fecha_cirugia).toDate()
    : null
  const trabajoSocialNumero = dataRadicacion?.trabajo_social_numero_orden
  const trabajoSocialObservacion = dataRadicacion?.trabajo_social_observaciones

  const proveedor = dataRadicacion?.radicacion_proveedor
  const presupuestoRegionalSaldo =
    dataRadicacion?.comite_regional_presupuesto_saldo || 0
  const definicionComiteRegional =
    dataRadicacion?.radicacion_definicion_comite_regional
  const triage = dataRadicacion?.radicacion_trigae
  const observacionComiteRegional = dataRadicacion?.comite_regional_observacion
  const pertinenciaMedica = dataRadicacion?.comite_regional_pertinencia_medica
  const historiaClinicaFiles = dataRadicacion?.historia_clinica.map((file) => {
    const fileRelId = file.id
    const { folder, uploaded_by, modified_by, filesize, ...restProps } =
      file.directus_files_id
    return {
      fileRelId,
      folder: folder?.id,
      uploaded_by: uploaded_by?.id,
      modified_by: modified_by?.id,
      filesize: +filesize,
      ...restProps,
    } as UploadedFile
  })

  const presupuestoActualFlat = paciente?.paciente_ips_primaria
    ?.map((item: any) =>
      item.ips_primaria_id?.ips_primaria_contrato.map(
        (item: any) => item?.contrato_id?.presupuesto_actual,
      ),
    )
    .flat(2)

  const presupuestoComite = presupuestoActualFlat?.reduce(
    (acc: number, item: number) => acc + item,
    0,
  )

  const presupuestoRegional = paciente?.paciente_ips_primaria
    .map((item: any) =>
      item.ips_primaria_id?.ips_primaria_contrato.map(
        (item: any) => item?.contrato_id,
      ),
    )
    .flat(2)

  const presupuestoRegionalActual =
    presupuestoRegional
      ?.map((item: any) => item?.contrato_regional)
      .reduce(
        (acc: number, item: { presupuesto_actual_regional: number }) =>
          acc + item.presupuesto_actual_regional,
        0,
      ) || 0

  useEffect(() => {
    refetch({ id })
  }, [tableRadicaciones])

  return {
    riesgo,
    diagnostico,
    cup,
    especialidad,
    medico_especialista,
    observaciones,
    trabajoSocialCirugia,
    trabajoSocialFecha,
    trabajoSocialNumero,
    presupuestoComite,
    trabajoSocialObservacion,
    proveedor,
    presupuestoRegionalActual,
    presupuestoRegionalSaldo,
    definicionComiteRegional,
    triage,
    observacionComiteRegional,
    pertinenciaMedica,
    dataRadicacion,
    loadingRadicacion,
    historiaClinicaFiles,
  }
}

export default useGetRadicacionInfo
