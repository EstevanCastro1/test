import {
  CupID,
  CupOptionDirectus,
  IPSPrimaria,
  IdCodigoDirectus,
  IdNameDirectus,
  ListDirectus,
  Medico,
  OptionDirectus,
  Proveedor,
  Proveedores,
} from '@interfaces/commons'
import { GET_INFO_IPS_PRIMARIA, GET_INFO_TO_DROPDOWN, PROVEEDOR } from '@utils'
import { UUID } from 'crypto'
import { useQuery } from '@apollo/client'
import { useEffect, useState } from 'react'
import { UseFormReturn, useWatch } from 'react-hook-form'

const useInfoDropDown = (
  handleForm: UseFormReturn<any, any, any>,
  patientId?: UUID,
) => {
  const { getValues, control } = handleForm

  const { data: dataDropdown, loading: loadingDropdown } =
    useQuery<ListDirectus>(GET_INFO_TO_DROPDOWN)
  const { data: dataProveedores, loading: loadingProveedores } =
    useQuery(PROVEEDOR)
  const { data: dataIpsPrimaria, loading: loadingIpsPrimaria } = useQuery(
    GET_INFO_IPS_PRIMARIA,
    { variables: { id: patientId } },
  )

  const [medicos, setMedicos] = useState<Medico[]>([])
  const [especialidades, setEspecialidades] = useState<IdNameDirectus[]>([])
  const [diagnosticos, setDiagnosticos] = useState<OptionDirectus[]>([])
  const [definiciones, setDefiniciones] = useState<IdNameDirectus[]>([])
  const [triage, setTriage] = useState<IdCodigoDirectus[]>([])
  const [cups, setCups] = useState<CupOptionDirectus[]>([])
  const [proveedores, setProveedores] = useState<Proveedor[]>([])
  const especialidadWatch = useWatch({ control, name: 'especialidad' })
  const cupsWatch = useWatch({ control, name: 'cups' })

  useEffect(() => {
    if (dataDropdown && !loadingDropdown) {
      setEspecialidades([...dataDropdown?.especialidad])
      setDiagnosticos([...dataDropdown?.diagnostico])
      setDefiniciones([...dataDropdown?.definicion_comite_regional])
      setTriage([...dataDropdown?.triage])
    }
  }, [dataDropdown])

  useEffect(() => {
    if (dataDropdown && !loadingDropdown) {
      const especialidadId = especialidades?.find(
        (e) => e.nombre === getValues('especialidad')?.nombre,
      )?.id
      const medicos = [...dataDropdown?.medico] || []

      const medicosFiltered = medicos?.filter((medico) => {
        const especialidadesMedicosIds = medico?.medico_especialidad?.map(
          (me) => me.especialidad_id.id,
        )
        return especialidadId
          ? especialidadesMedicosIds.includes(especialidadId)
          : null
      })

      setMedicos(medicosFiltered)
    }
  }, [especialidadWatch, especialidades])

  useEffect(() => {
    if (dataIpsPrimaria && !loadingIpsPrimaria) {
      const IPSPrimaria: IPSPrimaria[] =
        dataIpsPrimaria?.paciente_by_id.paciente_ips_primaria
      const cupsIps = IPSPrimaria?.flatMap((ips) => {
        return ips?.ips_primaria_id?.ips_primaria_contrato?.flatMap(
          (contrato) => {
            return contrato?.contrato_id?.contrato_cup?.map((cup) => {
              return JSON.stringify(cup.cup_id)
            })
          },
        )
      })
      const cupsWithoutDuplicates = Array.from(new Set(cupsIps))
      const cups: CupOptionDirectus[] = cupsWithoutDuplicates.map((cup) =>
        JSON.parse(cup),
      )
      setCups(cups)
    }
  }, [dataIpsPrimaria])

  useEffect(() => {
    if (dataProveedores && !loadingProveedores) {
      const proveedor = dataProveedores?.cup_valor as Proveedores[]
      const proveedoresMap: any = {}

      proveedor?.forEach((p) => {
        const proveedorNombre = p?.cup_valor_proveedor[0]?.proveedor_id?.nombre
        const proveedorId = p?.cup_valor_proveedor[0]?.proveedor_id?.id

        if (proveedorNombre) {
          if (!proveedoresMap[proveedorNombre]) {
            proveedoresMap[proveedorNombre] = {
              id: proveedorId,
              proveedor: proveedorNombre,
              cups: [],
            }
          }

          // Agregar los cups al proveedor correspondiente con sus respectivos valores
          p?.cup_valor_cup.forEach((cup) => {
            proveedoresMap[proveedorNombre].cups.push({
              codigo: cup.cup_id.codigo,
              descripcion: cup.cup_id.descripcion,
              valor: p?.valor, // Asumimos que cada 'valor' es el mismo para todos los 'cups' del proveedor actual
              sameCode: getValues('cups').some(
                (c: CupID) => c.codigo === cup.cup_id.codigo,
              ),
            })
          })
        }
      })

      const proveedorObject: Proveedor[] = Object.values(proveedoresMap)
      setProveedores(proveedorObject)
    }
  }, [dataProveedores, cupsWatch])

  return {
    especialidades,
    diagnosticos,
    cups,
    loadingIpsPrimaria,
    loadingDropdown,
    medicos,
    definiciones,
    proveedores,
    triage,
  }
}

export default useInfoDropDown
