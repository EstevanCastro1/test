import { useQuery } from '@apollo/client'
import { useRadicacionContext } from '@context/RadicacionContext'
import { UserBasicInfo } from '@interfaces/commons'
import { USER_BASIC_INFO } from '@utils'
import { useParams } from 'next/navigation'
import { useEffect } from 'react'

const useBasicInfoUser = () => {
  const { id } = useParams()
  const { setBasicInfoUser } = useRadicacionContext()

  const { data: dataUserBasicInfo, loading: loadingUserBasicInfo } =
    useQuery<UserBasicInfo>(USER_BASIC_INFO, {
      variables: { id },
    })

  useEffect(() => {
    if (!loadingUserBasicInfo) setBasicInfoUser(dataUserBasicInfo)
  }, [dataUserBasicInfo])

  return {
    dataUserBasicInfo,
    loadingUserBasicInfo,
  }
}

export default useBasicInfoUser
