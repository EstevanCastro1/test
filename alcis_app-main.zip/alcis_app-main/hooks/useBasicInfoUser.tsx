import { useQuery } from '@apollo/client'
import { UserBasicInfo } from '@interfaces/commons'
import { USER_BASIC_INFO } from '@utils'
import { useParams } from 'next/navigation'
import { useEffect } from 'react'

const useBasicInfoUser = () => {
  const { id } = useParams()
  const { data: dataUserBasicInfo, loading: loadingUserBasicInfo } =
    useQuery<UserBasicInfo>(USER_BASIC_INFO, {
      variables: { id },
    })

  return {
    dataUserBasicInfo,
    loadingUserBasicInfo,
  }
}

export default useBasicInfoUser
