import { deleteFileToDirectus, uploadFileToDirectus } from '@utils/api'
import { UUID } from 'crypto'

const useDirectusFiles = () => {
  const uploadFile = async (file: File, folderId: UUID) => {
    const formData = new FormData()
    formData.append('folder', folderId)
    formData.append('file', file)
    return await uploadFileToDirectus(formData)
  }

  const deleteFile = async (fileId: UUID) => await deleteFileToDirectus(fileId)

  return { uploadFile, deleteFile }
}

export default useDirectusFiles
