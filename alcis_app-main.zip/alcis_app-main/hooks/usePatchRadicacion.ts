import { patchRadicacion } from '@utils/api'
import { UUID } from 'crypto'

const usePatchRadicacion = () => {
  const executePatch = async (qxId: UUID, payload: any) => {
    return await patchRadicacion(qxId, payload)
  }

  const deleteUploadFile = (qxId: UUID, fileRelId: number) => {
    const payload = {
      historia_clinica: {
        delete: [fileRelId],
      },
    }
    return executePatch(qxId, payload)
  }

  const updateUploadedFiles = (qxId: UUID, fileId: UUID) => {
    const payload = {
      historia_clinica: {
        create: [
          {
            radicacion_id: qxId,
            directus_files_id: {
              id: fileId,
            },
          },
        ],
      },
    }
    return executePatch(qxId, payload)
  }

  return { updateUploadedFiles, deleteUploadFile }
}

export default usePatchRadicacion
