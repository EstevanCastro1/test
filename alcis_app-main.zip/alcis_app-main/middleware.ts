import { PATHS } from '@interfaces/commons'
import { COOKIES_KEYS } from '@utils/constants'
import { NextRequest, NextResponse } from 'next/server'

export function middleware(req: NextRequest) {
  const cookie = req.cookies.get(COOKIES_KEYS.accessToken)
  const pathname = req.nextUrl.pathname

  if (pathname === PATHS.login && cookie && cookie.value.trim() !== '') {
    return NextResponse.redirect(new URL(PATHS.home, req.url))
  }

  if (pathname !== PATHS.login && (!cookie || cookie?.value.trim() == '')) {
    return NextResponse.redirect(new URL(PATHS.login, req.url))
  }
}

export const config = {
  matcher: [
    /*a
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!api|_next/static|_next/image|favicon.ico|public/|assets/).*)',
  ],
}
