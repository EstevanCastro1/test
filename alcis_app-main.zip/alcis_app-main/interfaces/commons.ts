import { PROCESS_STATUS } from '@utils/constants'
import { UUID } from 'crypto'

export const PATHS = {
  login: '/login',
  home: '/',
  comite: '/comite',
  radicador: '/radicador',
  gestor_operativo: '/gestoroperativo',
  radicacion: '/radicacion',
}

export interface LoginFormInput {
  email: string
  password: string
}
export interface Menu {
  menu_principal: MenuPrincipal[]
}

export interface MenuPrincipal {
  id: string
  codigo: string
  nombre: string
  ruta: string
}

export interface Medico {
  id: UUID
  nombre: string
  medico_especialidad: MedicoEspecialidad[]
}

export interface MedicoEspecialidad {
  especialidad_id: {
    id: UUID
    nombre: string
  }
}

export interface Especialidad {
  id: UUID
  nombre: string
}

export interface CupOptionDirectus {
  id: UUID
  codigo: string
  descripcion: string
  resoluciones: string
  no_tr2: boolean
}

export interface OptionDirectus {
  id: UUID
  codigo: string
  descripcion: string
}

export interface Riesgo {
  label: string
  code: string
}

export interface RadicacionesTableProps {
  pacienteID: UUID
}

export interface DefinicionComiteRegional {
  id: UUID
  status: string
  nombre: string
}

export interface Radicacion {
  id: UUID
  date_created: string
  date_updated: string
  riesgo: string
  process_status: string
  radicacion_definicion_comite_regional: DefinicionComiteRegional
  radicacion_cup: RadicacionCup[]
  radicacion_diagnostico: RadicacionDiagnostico[]
}

export interface RadicacionCup {
  cup_id: CupOptionDirectus
}

export interface RadicacionDiagnostico {
  diagnostico_id: OptionDirectus
}

export type DataTableDate = {
  date: Date
  timestamp: number
  formated: string
}

export interface RadicacionesTable {
  id: string
  fecha_de_registro: DataTableDate
  dias_de_gestion: number
  riesgo: string
  estado_proceso: PROCESS_STATUS
  estado_comite_regional: string
  cups: CupOptionDirectus[]
  diagnosticos: OptionDirectus[]
}

export interface RiesgoOption {
  label: string
  code: string
}

export interface IdCodigoDirectus {
  codigo: string
  id: UUID
}

export interface RadicacionForm {
  direccion: string
  barrio: string
  telefono: string
  celular1: string
  celular2: string
  email: string
  redesSociales: boolean
  riesgo: RiesgoOption | null
  especialidad: IdNameDirectus | null
  medico: Medico | null
  observaciones: string
  diagnosticos: OptionDirectus[]
  cups: CupOptionDirectus[]
  proveedor: IdNameDirectus | null
  presupuesto_regional: number
  presupuesto_comite: number
  saldo_presupuesto: number
  definicion_comite: IdNameDirectus | null
  triage: IdCodigoDirectus | null
  observaciones_comite: string
  pertinencia_medica: string
  numero_de_orden: string
  cirugia_ejecutada: boolean | null
  fecha_cirugia: Date | null
  observacion_gestor: string
}

export interface HistoriaClinicaFileDirectus {
  id: number
  directus_files_id: {
    id: UUID
    filename_disk: string
    filename_download: string
    title: string
    type: string
    folder: {
      id: UUID
      name: string
    }
    uploaded_by: {
      id: UUID
    }
    uploaded_on: string
    modified_by: {
      id: UUID
    }
    modified_on: string
    filesize: string
    width: number
    height: number
    description: string
    location: string
  }
}

export interface RadicacionDirectus {
  riesgo: string
  radicacion_diagnostico: RadicacionDiagnostico[]
  radicacion_cup: RadicacionCup[]
  radicacion_especialidad: IdNameDirectus
  radicacion_medico: IdNameDirectus
  observacion_radicado: string
  trabajo_social_numero_orden: string
  trabajo_social_fecha_cirugia: Date
  trabajo_social_cirugia_ejecutada: boolean
  trabajo_social_observaciones: string
  radicacion_proveedor: IdNameDirectus
  comite_regional_presupuesto_saldo: number | null
  radicacion_definicion_comite_regional: Radicacion
  radicacion_trigae: OptionDirectus
  comite_regional_observacion: string
  comite_regional_pertinencia_medica: string
  historia_clinica: HistoriaClinicaFileDirectus[]
}

export interface ListDirectus {
  diagnostico: OptionDirectus[]
  cup: CupOptionDirectus[]
  especialidad: IdNameDirectus[]
  medico: Medico[]
  proveedor: IdNameDirectus[]
  definicion_comite_regional: IdNameDirectus[]
  triage: any[]
}

export interface IdNameDirectus {
  id: UUID
  nombre: string
}

export interface UserBasicInfo {
  paciente: Paciente[]
}

export interface Paciente {
  id: UUID
  status: string
  direccion: string
  barrio: string
  telefono: null
  celular_1: string
  celular_2: null
  email: string
  redes_sociales: boolean
  nombre_completo: string
  edad: string
  identificacion: string
  sexo: string
  departamento: string
  municipio: string
  fecha_nacimiento: string
  paciente_ips_primaria: PacienteIPSPrimaria[]
  paciente_radicacion: PacienteRadicacion[]
}

export interface PacienteIPSPrimaria {
  ips_primaria_id: IPSPrimariaID
}

export interface IPSPrimariaID {
  nombre: string
}

export interface PacienteRadicacion {
  id: string
  radicacion_id: Radicacion
}

export interface IPSPrimaria {
  ips_primaria_id: IPSPrimariaID
}

export interface IPSPrimariaID {
  ips_primaria_contrato: IPSPrimariaContrato[]
}

export interface IPSPrimariaContrato {
  contrato_id: ContratoID
}

export interface ContratoID {
  contrato_cup: ContratoCup[]
}

export interface ContratoCup {
  cup_id: CupID
}

export interface CupID {
  id: string
  codigo: string
  descripcion: string
}

export interface Proveedores {
  valor: number
  cup_valor_proveedor: CupValorProveedor[]
  cup_valor_cup: ContratoCup[]
}

export interface CupValorProveedor {
  proveedor_id: ProveedorID
}

export interface ProveedorID {
  id: UUID
  nombre: string
}

export interface CupIDProveedor {
  id: string
  codigo: string
  descripcion: string
  sameCode: boolean
  valor: number
}

export interface Proveedor {
  cups: CupIDProveedor[]
  proveedor: string
  valor: number
}

export interface UploadedFile {
  id: UUID
  fileRelId: number
  filename_disk: string
  filename_download: string
  title: string
  type: string
  folder: UUID
  uploaded_by: string | null
  uploaded_on: string
  modified_by: string | null
  modified_on: string
  filesize: number
  width: number
  height: number
  description: string
  location: string
}

export interface DecodedToken {
  exp: number
}

export type AuthLogin = {
  access_token: string
  refresh_token: string
  expires: number
}

export type ComiteStatusKey =
  | 'anulado'
  | 'aprobado'
  | 'en_tramite'
  | 'otros'
  | 's_s_ampliacion'
  | 'recobro'
