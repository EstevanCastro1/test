'use client'

import { RadicacionesTable, UserBasicInfo } from '@interfaces/commons'
import {
  Dispatch,
  SetStateAction,
  createContext,
  useContext,
  useState,
} from 'react'

type RadicacionContextType = {
  tableRadicaciones: RadicacionesTable[]
  setTableRadicaciones: Dispatch<SetStateAction<RadicacionesTable[]>>
  tmpFilesToCreate: File[]
  setTmpFilesToCreate: Dispatch<SetStateAction<File[]>>
  basicInfoUser: UserBasicInfo | undefined
  setBasicInfoUser: Dispatch<UserBasicInfo | undefined>
}

const radicacionContextDefaultValues: RadicacionContextType = {
  tableRadicaciones: [],
  setTableRadicaciones: () => {},
  tmpFilesToCreate: [],
  setTmpFilesToCreate: () => {},
  basicInfoUser: undefined,
  setBasicInfoUser: () => {},
}

export const RadicacionContext = createContext<RadicacionContextType>(
  radicacionContextDefaultValues,
)

export const useRadicacionContext = () => {
  return useContext(RadicacionContext)
}

export const RadicacionProvider = ({
  children,
}: {
  children: React.ReactNode
}) => {
  const [tableRadicaciones, setTableRadicaciones] = useState<
    RadicacionesTable[]
  >([])
  const [tmpFilesToCreate, setTmpFilesToCreate] = useState<File[]>([])
  const [basicInfoUser, setBasicInfoUser] = useState<UserBasicInfo | undefined>(
    undefined,
  )

  return (
    <RadicacionContext.Provider
      value={{
        tableRadicaciones,
        setTableRadicaciones,
        tmpFilesToCreate,
        setTmpFilesToCreate,
        basicInfoUser,
        setBasicInfoUser,
      }}
    >
      {children}
    </RadicacionContext.Provider>
  )
}
