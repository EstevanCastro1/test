'use client'

import { RadicacionesTable } from '@interfaces/commons'
import {
  Dispatch,
  SetStateAction,
  createContext,
  useContext,
  useState,
} from 'react'

type RadicacionContextType = {
  tableRadicaciones: RadicacionesTable[]
  setTableRadicaciones: Dispatch<SetStateAction<RadicacionesTable[]>>
  tmpFilesToCreate: File[]
  setTmpFilesToCreate: Dispatch<SetStateAction<File[]>>
}

const radicacionContextDefaultValues: RadicacionContextType = {
  tableRadicaciones: [],
  setTableRadicaciones: () => {},
  tmpFilesToCreate: [],
  setTmpFilesToCreate: () => {},
}

export const RadicacionContext = createContext<RadicacionContextType>(
  radicacionContextDefaultValues,
)

export const useRadicacionContext = () => {
  return useContext(RadicacionContext)
}

export const RadicacionProvider = ({
  children,
}: {
  children: React.ReactNode
}) => {
  const [tableRadicaciones, setTableRadicaciones] = useState<
    RadicacionesTable[]
  >([])
  const [tmpFilesToCreate, setTmpFilesToCreate] = useState<File[]>([])

  return (
    <RadicacionContext.Provider
      value={{
        tableRadicaciones,
        setTableRadicaciones,
        tmpFilesToCreate,
        setTmpFilesToCreate,
      }}
    >
      {children}
    </RadicacionContext.Provider>
  )
}
