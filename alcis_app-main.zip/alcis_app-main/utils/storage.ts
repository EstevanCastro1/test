import Cookies from 'js-cookie'
import { expiresCookie } from './helpers'

export const getLocalStorage = (key: string) => {
  if (typeof window !== 'undefined')
    return JSON.parse(window.localStorage.getItem(key) as string)
}
export const setLocalStorage = (key: string, value: any) => {
  if (typeof window !== 'undefined')
    window.localStorage.setItem(key, JSON.stringify(value))
}

export const deleteLocalStorage = (key: string) => {
  if (typeof window !== 'undefined') window.localStorage.removeItem(key)
}

export const clearLocalStorage = () => {
  if (typeof window !== 'undefined') window.localStorage.clear()
}

export const getSessionStorage = (key: string) => {
  if (typeof window !== 'undefined')
    return JSON.parse(window.sessionStorage.getItem(key) as string)
}

export const setSessionStorage = (key: string, value: any) => {
  if (typeof window !== 'undefined')
    window.sessionStorage.setItem(key, JSON.stringify(value))
}

export const getCookie = (name: string) => Cookies.get(name)

export const setCookie = (name: string, value: any = '') => {
  Cookies.set(name, value, {
    path: '/',
    expires: expiresCookie(),
    sameSite: 'Lax',
  })
}

export const deleteCookie = (name: string, value: any = '') => {
  Cookies.remove(name, { path: '/' })
}
