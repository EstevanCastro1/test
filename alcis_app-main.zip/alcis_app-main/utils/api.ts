import axios from 'axios'
import { UUID } from 'crypto'
import { deleteCookie, getCookie, setCookie } from './storage'
import { REQUEST_ATTEMPT_NUMBER, COOKIES_KEYS } from './constants'
import { jwtDecode } from 'jwt-decode'
import { AuthLogin, DecodedToken, PATHS } from '@interfaces/commons'
import { generateURLAssetsWithTokenAsync } from './url-access-token'
import axiosInstance from './axiosInstance'

export const uploadFileToDirectus = async (formData: FormData) => {
  try {
    const res = await axiosInstance.post('files', formData)
    return res.data?.data
  } catch (error: any) {
    throw new Error(error)
  }
}

export const deleteFileToDirectus = async (id: string) => {
  try {
    const res = await axiosInstance.delete('files', { data: [id] })
    return res.data?.data
  } catch (error: any) {
    throw new Error(error)
  }
}

export const downloadFileFromDirectus = async (id: UUID) => {
  try {
    const urlWithToken = await generateURLAssetsWithTokenAsync(id, {
      fit: 'cover',
    })
    const res = await axios.get(urlWithToken, { responseType: 'blob' })
    return res?.data
  } catch (error: any) {
    throw new Error(error)
  }
}

export const patchRadicacion = async (qxId: UUID, payload: any) => {
  try {
    const res = await axiosInstance.patch(`items/radicacion/${qxId}`, payload)
    return res.data?.data
  } catch (error: any) {
    throw new Error(error)
  }
}

export const fetch_retry = async (
  url: RequestInfo | URL,
  options: RequestInit | undefined,
  n: number,
): Promise<Response> => {
  try {
    return await fetch(url, options)
  } catch (err) {
    if (n === 1) throw err
    return await fetch_retry(url, options, n - 1)
  }
}

export const fetchRefreshToken = async (refresh_token: string) => {
  const response = await fetch_retry(
    `${process.env.NEXT_PUBLIC_DIRECTUS_BASE_URL}auth/refresh`,
    {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ refresh_token }),
    },
    REQUEST_ATTEMPT_NUMBER,
  )
  const content = await response?.json()
  return content?.data
}

const isTokenExpired = (token: string) => {
  try {
    const decoded = jwtDecode<DecodedToken>(token)
    const currentTime = Math.floor(Date.now() / 1000)
    if (decoded?.exp) return decoded.exp - currentTime < 0
  } catch (error) {
    console.error('Error decoding token:', error)
  }
  // If the token is malformed or doesn't have an expiration time, consider it expired
  return true
}

export const deleteAlcisCookies = () => {
  deleteCookie(COOKIES_KEYS.accessToken)
  deleteCookie(COOKIES_KEYS.refreshToken)
}

export const redirectToLogin = () => {
  deleteAlcisCookies()
  window.location.href = PATHS.login
}

export const refreshToken = async () => {
  let newToken = null
  const refreshToken = getCookie(COOKIES_KEYS.refreshToken) || ''
  const accessToken = getCookie(COOKIES_KEYS.accessToken) || ''

  if (!refreshToken || !accessToken) redirectToLogin()
  if (!isTokenExpired(accessToken)) return accessToken

  try {
    console.info('Refreshing token...')
    const response: AuthLogin = await fetchRefreshToken(refreshToken)
    if (response) {
      newToken = response.access_token
      setCookie(COOKIES_KEYS.accessToken, response.access_token)
      setCookie(COOKIES_KEYS.refreshToken, response.refresh_token)
      console.info('Refresh token DONE!')
    } else {
      redirectToLogin()
    }
  } catch (error: any) {
    console.error(error)
    redirectToLogin()
  }

  return newToken
}
