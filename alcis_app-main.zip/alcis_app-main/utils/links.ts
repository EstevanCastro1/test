import { Observable } from '@apollo/client'
import { onError } from '@apollo/client/link/error'
import { redirectToLogin, refreshToken } from '@utils/api'
import { getCookie } from '@utils/storage'
import { setContext } from '@apollo/client/link/context'
import { COOKIES_KEYS } from '@utils/constants'

let isRefreshing = false
let pendingRequests: ((token: string | null) => void)[] = []

const addPendingRequest = (callback: (token: string | null) => void) => {
  pendingRequests.push(callback)
}

const resolvePendingRequests = (newToken: string | null) => {
  pendingRequests.forEach((callback) => callback(newToken))
  pendingRequests = []
}

// errorLink: Interceptor de las peticiones graphql
export const errorLink = onError(
  ({ graphQLErrors, networkError, operation, forward }) => {
    if (graphQLErrors) {
      for (const err of graphQLErrors) {
        switch (err.extensions.code) {
          case 'UNAUTHENTICATED':
          case 'TOKEN_EXPIRED':
            if (!isRefreshing) {
              isRefreshing = true
              return new Observable((observer) => {
                ;(async () => {
                  try {
                    const newToken = await refreshToken()
                    resolvePendingRequests(newToken)
                    const oldHeaders = operation.getContext().headers
                    operation.setContext({
                      headers: {
                        ...oldHeaders,
                        authorization: `Bearer ${newToken}`,
                      },
                    })
                    isRefreshing = false
                  } catch (error) {
                    console.error('Error fetching new token', error)
                    observer.error(error)
                    isRefreshing = false
                    resolvePendingRequests(null)
                    return
                  }

                  forward(operation).subscribe({
                    next: observer.next.bind(observer),
                    error: observer.error.bind(observer),
                    complete: observer.complete.bind(observer),
                  })
                })()
              })
            } else {
              return new Observable((observer) => {
                addPendingRequest((newToken) => {
                  if (newToken) {
                    const oldHeaders = operation.getContext().headers
                    operation.setContext({
                      headers: {
                        ...oldHeaders,
                        authorization: `Bearer ${newToken}`,
                      },
                    })
                    forward(operation).subscribe({
                      next: observer.next.bind(observer),
                      error: observer.error.bind(observer),
                      complete: observer.complete.bind(observer),
                    })
                  } else {
                    observer.error(new Error('Failed to refresh token'))
                  }
                })
              })
            }
        }
      }
    }

    if (networkError) {
      console.log(`[Network error]: ${networkError}`)
      redirectToLogin()
    }
  },
)

export const authLink = setContext((_, { headers }) => {
  const token = getCookie(COOKIES_KEYS.accessToken)
  return {
    headers: {
      ...headers,
      authorization: token ? `Bearer ${token}` : '',
    },
  }
})
