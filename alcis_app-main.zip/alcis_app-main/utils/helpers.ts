import moment from 'moment'
import 'moment/locale/es'

export const getFormatedDateToEs = (date: string, format = 'll') =>
  moment(date).locale('es').format(format)

export const formatearMoneda = (value: number) =>
  new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value)

export const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/

export function daysToMilliseconds(days: number) {
  // 👇️        hour  min  sec  ms
  return days * 24 * 60 * 60 * 1000
}

export const expiresCookie = () => {
  const expireDays = Number(process.env.NEXT_PUBLIC_COOKIE_EXPIRE_DAYS)
  return new Date(new Date().getTime() + daysToMilliseconds(expireDays))
}

export const formatTimestampToDateTime = (timestamp: number) => {
  const dateObj = new Date(timestamp)

  // Custom array of abbreviated month names without periods
  const monthNames = [
    'Ene',
    'Feb',
    'Mar',
    'Abr',
    'May',
    'Jun',
    'Jul',
    'Ago',
    'Sep',
    'Oct',
    'Nov',
    'Dic',
  ]

  // Get the day, month, and year
  const day = dateObj.getDate()
  const month = monthNames[dateObj.getMonth()]
  const year = dateObj.getFullYear()

  // Format time as 'hh:mm AM/PM' with uppercase and without periods
  const timeFormatter = new Intl.DateTimeFormat('en-US', {
    hour: 'numeric',
    minute: 'numeric',
    hour12: true,
  })

  let time = timeFormatter.format(dateObj)
  time = time.replace(/\./g, '').toUpperCase() // Remove periods and make uppercase

  return {
    date: `${month} ${day} de ${year}`,
    time,
  }
}
