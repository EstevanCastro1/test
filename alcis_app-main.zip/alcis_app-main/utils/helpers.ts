import moment from 'moment'
import 'moment/locale/es'

export const getFormatedDateToEs = (date: string, format = 'll') =>
  moment(date).locale('es').format(format)

export const formatearMoneda = (value: number) =>
  new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value)

export const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/

export function daysToMilliseconds(days: number) {
  // 👇️        hour  min  sec  ms
  return days * 24 * 60 * 60 * 1000
}

export const expiresCookie = () => {
  const expireDays = Number(process.env.NEXT_PUBLIC_COOKIE_EXPIRE_DAYS)
  return new Date(new Date().getTime() + daysToMilliseconds(expireDays))
}
