import { RadicadoPDFInfo } from '@interfaces/commons'
import * as pdfMake from 'pdfmake/build/pdfmake'
import * as pdfFonts from 'pdfmake/build/vfs_fonts'
import { TDocumentDefinitions } from 'pdfmake/interfaces'
;(<any>pdfMake).vfs = pdfFonts.pdfMake.vfs

export const printRadicado = (info: RadicadoPDFInfo) => {
  const content = [
    {
      text: 'Radicación Solicitud de Cirugías\n\n',
      style: 'title',
    },
    {
      text: `Radicación #${info.numeroRadicado}`,
      style: 'marginDef1',
    },
    {
      text: `Fecha de radicación: ${info.fechaRadicado.date}, Hora local: ${info.fechaRadicado.time}`,
      style: 'marginDef1',
    },
    {
      text: `Sede de atención: ${info.ips.nombre}`,
      margin: [20, 0, 0, 20],
    },
    {
      text: `Respetado(a) señor(a): ${info.paciente}. Reciba un cordial saludo en nombre de Bienestar IPS S.A. Su solicitud de cirugía se encuentra en trámite. Recibirá información de su trámite vía mensaje de texto, correo electrónico o vía telefónica.`,
      alignment: 'justify',
      margin: [0, 0, 0, 20],
    },
    {
      text: `Para mayor información sobre su caso, llamar a: ${info.ips.telefono}`,
      style: 'marginDef2',
    },
    {
      text: 'Call Center Costa Atlántica: 3203509830',
      style: 'marginDef2',
    },
    {
      text: 'Call Center Cundinamarca: 320350988',
      style: 'marginDef2',
    },
    {
      text: 'A través del chat: https://bienestarips.com/',
      style: 'marginDef2',
    },
    {
      text: 'ó al correo: servicioalcliente@bienestarips.com',
      margin: [0, 0, 0, 30],
    },
    {
      text: `Gestionado por ${info.radicador}`,
      style: 'marginDef2',
    },
    {
      text: 'Atención al Cliente',
    },
  ]

  generatePdf(content)
}

const generatePdf = (content: any) => {
  const docDefinition: TDocumentDefinitions = {
    content,
    pageSize: 'LETTER',
    styles: {
      title: {
        fontSize: 20,
        bold: true,
        alignment: 'center',
      },
      marginDef1: {
        alignment: 'justify',
        margin: [20, 0, 0, 7],
      },
      marginDef2: {
        alignment: 'justify',
        margin: [0, 0, 0, 7],
      },
    },
    defaultStyle: {
      fontSize: 12,
    },
  }

  pdfMake.createPdf(docDefinition).open()
}
