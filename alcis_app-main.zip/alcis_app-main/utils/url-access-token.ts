import { refreshToken } from './api'
import { COOKIES_KEYS } from './constants'
import { getCookie } from './storage'

const addSearchToken = (
  id: string,
  queryParams: Record<string, string>,
  token: string,
) => {
  if (token) queryParams = { ...queryParams, access_token: token }
  const searchParams = new URLSearchParams(queryParams)

  return `${
    process.env.NEXT_PUBLIC_DIRECTUS_BASE_URL
  }assets/${id}?${searchParams.toString()}`
}

export const generateURLAssetsWithToken = (
  id: string,
  queryParams: Record<string, string>,
) => {
  if (id) {
    const token = getCookie(COOKIES_KEYS.accessToken) || ''
    return addSearchToken(id, queryParams, token)
  }
  return 'NOT_FOUND'
}

export const generateURLAssetsWithTokenAsync = async (
  id: string,
  queryParams: Record<string, string>,
) => {
  if (id) {
    const token = (await refreshToken()) || ''
    return addSearchToken(id, queryParams, token)
  }
  return 'NOT_FOUND'
}
