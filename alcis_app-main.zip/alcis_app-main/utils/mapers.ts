import {
  DataTableDate,
  PacienteRadicacion,
  Radicacion,
  RadicacionForm,
  RadicacionesTable,
} from '@interfaces/commons'
import moment from 'moment'
import { getFormatedDateToEs } from './helpers'
import { PROCESS_STATUS, STATUS } from './constants'

export const radicacionesTableMapper = (
  radicaionesDirectus: PacienteRadicacion[],
) =>
  radicaionesDirectus?.map((item) => {
    const radicacion = item.radicacion_id
    const fechaCreated = moment(radicacion?.date_created)
    const fechaUpdated = radicacion?.date_updated
      ? moment(radicacion?.date_updated)
      : null
    const numeroRadicado = radicacion?.id
    const fechaDeRegistro: DataTableDate = {
      date: fechaCreated.toDate(),
      timestamp: fechaCreated.valueOf(),
      formated: getFormatedDateToEs(radicacion?.date_created, 'ddd ll'),
    }
    const diasDeGestion = fechaUpdated
      ? fechaUpdated.diff(fechaCreated, 'days')
      : 0
    const riesgo = radicacion?.riesgo
    const estado_proceso = radicacion?.process_status
    const estado_comite_regional =
      radicacion?.radicacion_definicion_comite_regional?.nombre || null
    const cups = radicacion?.radicacion_cup.map((cup) => cup?.cup_id)
    const diagnosticos = radicacion?.radicacion_diagnostico.map(
      (diagngonstico) => diagngonstico.diagnostico_id,
    )

    return {
      id: numeroRadicado,
      fecha_de_registro: fechaDeRegistro,
      dias_de_gestion: diasDeGestion,
      riesgo,
      estado_proceso,
      estado_comite_regional,
      cups,
      diagnosticos,
    } as RadicacionesTable
  })

export const radicacionesTableMapperSingle = (
  radicaionDirectus: Radicacion,
) => {
  const fechaCreated = moment(radicaionDirectus.date_created)
  const fechaUpdated = radicaionDirectus.date_updated
    ? moment(radicaionDirectus.date_updated)
    : null
  const numeroRadicado = radicaionDirectus?.id
  const fechaDeRegistro: DataTableDate = {
    date: fechaCreated.toDate(),
    timestamp: fechaCreated.valueOf(),
    formated: getFormatedDateToEs(radicaionDirectus.date_created, 'ddd ll'),
  }
  const diasDeGestion = fechaUpdated
    ? fechaUpdated.diff(fechaCreated, 'days')
    : 0
  const riesgo = radicaionDirectus.riesgo
  const cups = radicaionDirectus.radicacion_cup.map((cup) => cup?.cup_id)
  const diagnosticos = radicaionDirectus.radicacion_diagnostico.map(
    (diagngonstico) => diagngonstico.diagnostico_id,
  )

  return {
    id: numeroRadicado,
    fecha_de_registro: fechaDeRegistro,
    dias_de_gestion: diasDeGestion,
    riesgo,
    cups,
    diagnosticos,
  } as RadicacionesTable
}

export const radicacionMapper = (radicacion: RadicacionForm) => {
  const proveedor = {
    id: radicacion?.proveedor?.id,
    nombre: radicacion.proveedor?.nombre,
  }

  return {
    status: STATUS.published,
    riesgo: radicacion.riesgo?.code,
    radicacion_diagnostico: radicacion?.diagnosticos?.map((diagnostico) => {
      return {
        diagnostico_id: {
          id: diagnostico?.id,
        },
      }
    }),
    radicacion_cup: radicacion?.cups?.map((cup) => {
      return {
        cup_id: {
          id: cup.id,
        },
      }
    }),
    radicacion_especialidad: {
      id: radicacion?.especialidad?.id,
    },
    radicacion_medico: {
      id: radicacion?.medico?.id,
    },
    observacion_radicado: radicacion?.observaciones,
    comite_regional_observacion: radicacion.observaciones_comite,
    radicacion_proveedor: proveedor,
    comite_regional_pertinencia_medica: radicacion.pertinencia_medica,
    comite_regional_presupuesto_saldo: Number(radicacion.saldo_presupuesto),
    radicacion_definicion_comite_regional: radicacion.definicion_comite,
    radicacion_trigae: radicacion.triage,
    trabajo_social_cirugia_ejecutada: radicacion.cirugia_ejecutada,
    trabajo_social_fecha_cirugia: radicacion?.fecha_cirugia
      ? moment(radicacion.fecha_cirugia).format('YYYY-MM-DD')
      : null,
    trabajo_social_numero_orden: radicacion.numero_de_orden,
    trabajo_social_observaciones: radicacion.observacion_gestor,
    process_status:
      radicacion.definicion_comite && radicacion.numero_de_orden
        ? PROCESS_STATUS.completado
        : PROCESS_STATUS.enProceso,
  }
}

export const updatePaciente = (paciente: RadicacionForm) => {
  return {
    direccion: paciente.direccion,
    barrio: paciente.barrio,
    telefono: paciente.telefono,
    celular_1: paciente.celular1,
    celular_2: paciente.celular2,
    email: paciente.email,
    redes_sociales: paciente.redesSociales,
  }
}
