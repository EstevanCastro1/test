import { gql } from '@apollo/client'

export const LOG_IN = gql`
  mutation LOG_IN($email: String!, $password: String!) {
    auth_login(email: $email, password: $password) {
      access_token
      refresh_token
    }
  }
`

export const LOG_OUT = gql`
  mutation LOG_OUT($refreshToken: String) {
    auth_logout(refresh_token: $refreshToken)
  }
`

export const NOMBRES = gql`
  query NOMBRES {
    nombres {
      name
      last_name
    }
  }
`

export const GET_USER = gql`
  query GET_USER {
    users_me {
      first_name
      last_name
      role {
        name
      }
    }
  }
`

export const GET_MENU = gql`
  query {
    menu_principal(filter: { status: { _eq: "published" } }) {
      id
      codigo
      nombre
      ruta
    }
  }
`

export const SHOW_PACIENTES_TO_CARDS = gql`
  query GET_PACIENTES($limit: Int!, $offset: Int!, $filter: paciente_filter!) {
    paciente(
      filter: $filter
      limit: $limit
      offset: $offset
      sort: ["cantidad_radicaciones", "nombre_completo"]
    ) {
      id
      status
      identificacion
      nombre_completo
      cantidad_radicaciones
      paciente_radicacion {
        id
        radicacion_id(filter: { status: { _eq: "published" } }) {
          id
          process_status
        }
      }
      paciente_ips_primaria {
        ips_primaria_id {
          nombre
        }
      }
    }
    paciente_aggregated(filter: $filter) {
      count {
        id
      }
    }
  }
`

export const GET_PACIENTE_TO_TABLE = gql`
  query GET_PACIENTE_TO_TABLE($id: String!) {
    paciente(filter: { id: { _eq: $id } }) {
      nombre_completo
      paciente_radicacion {
        id
        radicacion_id {
          date_created
        }
      }
    }
  }
`

export const USER_BASIC_INFO = gql`
  query USER_BASIC_INFO($id: String!) {
    paciente(filter: { id: { _eq: $id } }) {
      id
      direccion
      barrio
      telefono
      celular_1
      celular_2
      email
      redes_sociales
      nombre_completo
      edad
      identificacion
      sexo
      departamento
      municipio
      fecha_nacimiento
      paciente_ips_primaria {
        ips_primaria_id {
          nombre
          telefono
        }
      }
      paciente_radicacion {
        id
        radicacion_id {
          id
          riesgo
        }
      }
      paciente_ips_primaria {
        ips_primaria_id {
          ips_primaria_contrato {
            contrato_id {
              presupuesto_actual
              contrato_regional {
                presupuesto_actual_regional
              }
            }
          }
        }
      }
    }
  }
`

export const GET_INFO_TO_DROPDOWN = gql`
  query GET_INFO_TO_DROPDOWN {
    diagnostico(filter: { status: { _eq: "published" } }, limit: 100000) {
      id
      codigo
      descripcion
    }
    cup(filter: { status: { _eq: "published" } }, limit: 100000) {
      id
      codigo
      descripcion
    }
    especialidad(
      filter: { status: { _eq: "published" } }
      limit: 100000
      sort: ["nombre"]
    ) {
      id
      nombre
    }
    medico(
      filter: { status: { _eq: "published" } }
      limit: 100000
      sort: ["nombre"]
    ) {
      id
      nombre
      medico_especialidad {
        especialidad_id {
          id
          nombre
        }
      }
    }
    proveedor(filter: { status: { _eq: "published" } }, limit: 100000) {
      id
      nombre
    }
    definicion_comite_regional(
      filter: { status: { _eq: "published" } }
      limit: 100000
    ) {
      id
      nombre
    }
    triage(filter: { status: { _eq: "published" } }, limit: 100000) {
      id
      codigo
    }
  }
`

export const CREATE_RADICACION = gql`
  mutation create_radication($radicacion_data: create_radicacion_input!) {
    create_radicacion_item(data: $radicacion_data) {
      id
    }
  }
`

export const CANT_RAD_PACIENTE = gql`
  mutation SET_CANT_RAD_PACIENTE($id: ID!, $data: update_paciente_input!) {
    update_paciente_item(id: $id, data: $data) {
      id
    }
  }
`

export const ADD_RADICACION_TO_PATIENT = gql`
  mutation ADD_RADICACION_TO_PATIENT($data: create_paciente_radicacion_input!) {
    create_paciente_radicacion_item(data: $data) {
      paciente_id {
        paciente_radicacion {
          radicacion_id {
            id
            date_created
            date_updated
            riesgo
            radicacion_cup {
              cup_id {
                codigo
                descripcion
              }
            }
            radicacion_diagnostico {
              diagnostico_id {
                codigo
                descripcion
              }
            }
          }
        }
      }
    }
  }
`

export const GET_RADICACION_BY_USER = gql`
  query GET_RADICACION_BY_USER($id: ID!) {
    paciente_by_id(id: $id) {
      paciente_radicacion {
        id
        radicacion_id(filter: { status: { _eq: "published" } }) {
          id
          date_created
          date_updated
          riesgo
          process_status
          radicacion_definicion_comite_regional {
            id
            status
            nombre
          }
          radicacion_cup {
            cup_id {
              id
              codigo
              descripcion
              resoluciones
              no_tr2
            }
          }
          radicacion_diagnostico {
            diagnostico_id {
              id
              codigo
              descripcion
            }
          }
        }
      }
    }
  }
`

export const GET_RADICACION_BY_ID = gql`
  query GET_RADICACION_BY_ID($id: ID!) {
    radicacion_by_id(id: $id) {
      riesgo
      radicacion_diagnostico {
        diagnostico_id(filter: { status: { _eq: "published" } }) {
          id
          codigo
          descripcion
        }
      }
      radicacion_cup {
        cup_id(filter: { status: { _eq: "published" } }) {
          id
          codigo
          descripcion
          resoluciones
          no_tr2
        }
      }
      radicacion_especialidad(filter: { status: { _eq: "published" } }) {
        id
        nombre
      }
      radicacion_medico {
        id
        nombre
        medico_especialidad {
          especialidad_id(filter: { status: { _eq: "published" } }) {
            id
            nombre
          }
        }
      }
      observacion_radicado
      radicacion_proveedor(filter: { status: { _eq: "published" } }) {
        id
        nombre
      }
      comite_regional_presupuesto_saldo
      radicacion_definicion_comite_regional(
        filter: { status: { _eq: "published" } }
      ) {
        id
        nombre
      }
      radicacion_trigae(filter: { status: { _eq: "published" } }) {
        id
        codigo
      }
      comite_regional_observacion
      comite_regional_pertinencia_medica
      trabajo_social_numero_orden
      trabajo_social_fecha_cirugia
      trabajo_social_cirugia_ejecutada
      trabajo_social_observaciones
      historia_clinica {
        id
        directus_files_id {
          id
          filename_disk
          filename_download
          title
          type
          folder {
            id
            name
          }
          uploaded_by {
            id
          }
          uploaded_on
          modified_by {
            id
          }
          modified_on
          filesize
          width
          height
          description
          location
        }
      }
    }
  }
`

export const UPDATE_RADICACION = gql`
  mutation UPDATE_RADICACION(
    $id: ID!
    $radicacion_data: update_radicacion_input!
  ) {
    update_radicacion_item(id: $id, data: $radicacion_data) {
      id
      date_created
      date_updated
      riesgo
      radicacion_cup {
        cup_id {
          codigo
          descripcion
        }
      }
      radicacion_diagnostico {
        diagnostico_id {
          codigo
          descripcion
        }
      }
    }
  }
`

export const UPDATE_PACIENTE = gql`
  mutation UPDATE_PACIENTE($id: ID!, $paciente: update_paciente_input!) {
    update_paciente_item(id: $id, data: $paciente) {
      id
    }
  }
`

export const GET_INFO_IPS_PRIMARIA = gql`
  query GET_INFO_IPS_PRIMARIA($id: ID!) {
    paciente_by_id(id: $id) {
      paciente_ips_primaria {
        ips_primaria_id {
          ips_primaria_contrato {
            contrato_id {
              contrato_cup(limit: 100000) {
                cup_id(filter: { status: { _eq: "published" } }) {
                  id
                  codigo
                  descripcion
                  resoluciones
                  no_tr2
                }
              }
            }
          }
        }
      }
    }
  }
`

export const PROVEEDOR = gql`
  query PROVEEDOR {
    cup_valor {
      valor
      cup_valor_proveedor {
        proveedor_id {
          id
          nombre
        }
      }
      cup_valor_cup {
        cup_id {
          codigo
          descripcion
        }
      }
    }
  }
`
