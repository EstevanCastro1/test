import { ComiteStatusKey, RiesgoOption } from '@interfaces/commons'

export const MESSAGES = {
  ERROR: {
    invalidCrdentials:
      'La contraseña y el email no coinciden, prueba de nuevo.',
    requiredField: 'Este campo es obligatorio',
    invalidFormat: 'Formato no es valido',
  },
}

export const COOKIES_KEYS = {
  accessToken: 'alcis_access_token',
  refreshToken: 'alcis_refresh_token',
}

export enum ROLES {
  radicador = 'Radicador',
  comite_regional = 'Comite regional',
  gestor_operativo = 'Gestor Operativo',
  admin = 'Administrator',
}

export const RIESGOS: RiesgoOption[] = [
  {
    label: 'Juridico',
    code: 'juridico',
  },
  {
    label: 'Riesgo en salud',
    code: 'riesgo_salud',
  },
  {
    label: 'Sin riesgo',
    code: 'sin_riesgo',
  },
]

export const CODES = {
  radicacion: 'radicacion',
}

export const MAX_MB_GALLERY = 30
export const REQUEST_ATTEMPT_NUMBER = 1

export enum STATUS {
  published = 'published',
  draft = 'draft',
  archived = 'archived',
}

export enum PROCESS_STATUS {
  enProceso = 'en_proceso',
  completado = 'completado',
}

export const DEFINICION_COMITE_STATUS: Record<ComiteStatusKey, string> = {
  anulado: 'Anulado',
  aprobado: 'Aprobado',
  en_tramite: 'En tramite',
  otros: 'Otros',
  s_s_ampliacion: 'S/SAmpliacion',
  recobro: 'Recobro',
}
