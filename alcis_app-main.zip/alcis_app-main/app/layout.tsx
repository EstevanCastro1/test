import { Work_Sans } from 'next/font/google'
import { Providers } from '@components/templates'

import 'primereact/resources/themes/lara-light-blue/theme.css'
import 'primereact/resources/primereact.min.css'
import 'primeicons/primeicons.css'
import '@styles/globals.css'

const work_sans = Work_Sans({ subsets: ['latin'] })

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang='en'>
      <body className={work_sans.className}>
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
