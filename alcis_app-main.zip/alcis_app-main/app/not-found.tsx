import type { Metadata } from 'next'
import { NotFound } from '@components/templates'

export const metadata: Metadata = {
  title: 'Alcis | 404',
  description: 'Página no encontrada',
}

const NotFoundPage = () => <NotFound />

export default NotFoundPage
