import Home from '@components/templates/Home'

export const metadata = {
  title: 'Alcis | Home',
  description: 'Página home',
}

const HomePage = () => <Home />

export default HomePage
