import { Footer, Header } from '@components/organisms'
import React from 'react'

const MainLayout = ({
  children,
}: Readonly<{
  children: React.ReactNode
}>) => {
  return (
    <main className='flex flex-col justify-center min-h-screen items-center'>
      <Header />
      <div className='grow flex justify-center container max-w-[70rem] px-4'>
        {children}
      </div>
      <Footer />
    </main>
  )
}

export default MainLayout
