import { Radicacion } from '@components/templates'

export const metadata = {
  title: 'Alcis | Radicacion',
  description: 'Pagina de Radicacion del paciente',
}

const RadicacionByIdPage = () => <Radicacion />

export default RadicacionByIdPage
