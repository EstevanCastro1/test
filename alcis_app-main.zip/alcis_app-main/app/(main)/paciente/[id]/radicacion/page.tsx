import { Radicacion } from '@components/templates'

export const metadata = {
  title: 'Alcis | Radicacion',
  description: 'Pagina de Radicacion del paciente',
}

const RadicacionPage = () => <Radicacion />

export default RadicacionPage
