import { Paciente } from '@components/templates'

export const metadata = {
  title: 'Alcis | Paciente',
  description: 'Pagina del paciente',
}

const PacientePage = () => <Paciente />

export default PacientePage
