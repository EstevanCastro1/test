import { Comite } from '@components/templates'

export const metadata = {
  title: 'Alcis | Comite Regional',
  description: 'Página Comite Regional',
}

const ComitePage = () => <Comite />

export default ComitePage
