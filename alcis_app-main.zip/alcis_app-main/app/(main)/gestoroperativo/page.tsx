import { Gestor } from '@components/templates'

export const metadata = {
  title: 'Alcis | Gestor operativo',
  description: 'Pagina de Gestor operativo',
}

const GestorOperativoPage = () => <Gestor />

export default GestorOperativoPage
