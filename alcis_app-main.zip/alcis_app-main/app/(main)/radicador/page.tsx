import { Radicador } from '@components/templates'

export const metadata = {
  title: 'Alcis | Doctor',
  description: 'Página Doctor',
}

const DoctorPage = () => <Radicador />

export default DoctorPage
