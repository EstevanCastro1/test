import { Login } from '@components/templates'

export const metadata = {
  title: 'Alcis | Log-In',
  description: 'Alcis | Iniciar session',
}

const LoginPage = () => <Login />
export default LoginPage
