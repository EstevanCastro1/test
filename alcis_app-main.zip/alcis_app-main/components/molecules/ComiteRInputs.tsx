'use client'

import {
  CustomTextArea,
  CustomSelect,
  CustomButton,
  CustomInputNumber,
} from '@components/atoms'
import useInfoDropDown from '@hooks/useInfoDropDown'
import { Divider } from 'primereact/divider'
import { UseFormReturn } from 'react-hook-form'
import { useGetRadicacionInfo, useRole } from '@hooks'
import { UUID } from 'crypto'
import { useEffect } from 'react'
import { useParams } from 'next/navigation'
import { CupIDProveedor, Proveedor } from '@interfaces/commons'
import { formatearMoneda } from '@utils/helpers'
import { DropdownChangeEvent } from 'primereact/dropdown'
import { ROLES } from '@utils/constants'

interface RadicacionInputsProps {
  handleForm: UseFormReturn<any, any, any>
  isDisabled: boolean
  qxId: UUID
  isLoading?: boolean
}

const proveedorBodyTample = (proveedor: Proveedor) => {
  return proveedor ? (
    <div className='max-w-xl sm:max-w-2xl'>
      <p className='font-bold text-lg'>{proveedor.proveedor}</p>
      <ul className='flex flex-wrap gap-x-3'>
        {proveedor?.cups?.map((cup, index) => {
          return (
            <li
              className={` ${cup.sameCode ? 'text-lime-600' : 'text-red-600'}`}
              key={index}
            >
              <strong>{cup.codigo}</strong> ({formatearMoneda(cup.valor)})
            </li>
          )
        })}
      </ul>
    </div>
  ) : null
}

const ComiteRInputs = ({
  handleForm,
  isDisabled,
  qxId,
  isLoading,
}: RadicacionInputsProps) => {
  const { setValue, getValues } = handleForm

  const { id } = useParams()
  const { role } = useRole()
  const { proveedores, triage, definiciones } = useInfoDropDown(handleForm)

  const isComiteRegional = role === ROLES.comite_regional

  const {
    proveedor,
    definicionComiteRegional,
    observacionComiteRegional,
    pertinenciaMedica,
    presupuestoRegionalActual,
    triage: triageComite,
    dataRadicacion,
    loadingRadicacion,
    presupuestoComite,
    presupuestoRegionalSaldo,
  } = useGetRadicacionInfo(qxId, id as UUID)

  const proveedorValueTample = (proveedor: Proveedor) => {
    return proveedor ? (
      <p>{proveedor.proveedor}</p>
    ) : (
      getValues('proveedor')?.nombre || 'Seleccionar proveedor'
    )
  }

  const handleChangeProveedor = (e: DropdownChangeEvent) => {
    const proveedor: Proveedor = e.value
    const sumValorCups = proveedor?.cups?.reduce(
      (acc: number, cup: CupIDProveedor) =>
        acc + (cup.sameCode ? cup?.valor : 0),
      0,
    )
    setValue('saldo_presupuesto', presupuestoComite - sumValorCups)
  }

  useEffect(() => {
    if (dataRadicacion && !loadingRadicacion) {
      setValue('proveedor', proveedor)
      setValue('definicion_comite', definicionComiteRegional)
      setValue('observaciones_comite', observacionComiteRegional)
      setValue('pertinencia_medica', pertinenciaMedica)
      setValue('presupuesto_regional', presupuestoRegionalActual)
      setValue('presupuesto_comite', presupuestoComite)
      setValue('saldo_presupuesto', presupuestoRegionalSaldo)
      setValue('triage', triageComite)
    }
  }, [dataRadicacion])

  return (
    <div className='flex flex-col gap-5'>
      <Divider align='center' className='[&_.p-divider-content]:custom-divider'>
        <b>Gestión comité quirúrgico regional</b>
      </Divider>
      <section className='flex flex-col justify-center items-center'>
        <div className='grid md:grid-cols-4 sm:grid-cols-2 lg:grid-cols-3 gap-x-5 w-full'>
          <CustomSelect
            options={proveedores}
            handleForm={handleForm}
            name='proveedor'
            optionLabel='nombre'
            itemTemplate={proveedorBodyTample}
            valueTemplate={proveedorValueTample}
            label='Proveedor'
            disabled={isDisabled}
            placeholder='Seleccionar proveedor'
            onCustomChange={handleChangeProveedor}
            required={isComiteRegional}
          />
          <CustomInputNumber
            handleForm={handleForm}
            name='presupuesto_regional'
            label='Presupuesto regional actual'
            currency='COP'
            locale='es-CO'
            mode='currency'
            disabled
          />
          <CustomInputNumber
            handleForm={handleForm}
            name='presupuesto_comite'
            label='Presupuesto comité'
            currency='COP'
            mode='currency'
            locale='es-CO'
            disabled
          />
          <CustomInputNumber
            handleForm={handleForm}
            name='saldo_presupuesto'
            label='Saldo de presupuesto'
            currency='COP'
            locale='es-CO'
            mode='currency'
            disabled
          />
          <CustomSelect
            options={definiciones}
            optionLabel='nombre'
            handleForm={handleForm}
            name='definicion_comite'
            placeholder='Seleccionar definición'
            label='Definición comité regional'
            disabled={isDisabled}
            required={isComiteRegional}
          />
          <CustomSelect
            options={triage}
            handleForm={handleForm}
            name='triage'
            optionLabel='codigo'
            placeholder='Seleccionar triage'
            label='Triage'
            disabled={isDisabled}
            required={isComiteRegional}
          />
        </div>
        <div className='grid sm:grid-cols-2 gap-5 w-full'>
          <CustomTextArea
            handleForm={handleForm}
            name='observaciones_comite'
            disabled={isDisabled}
            label='Observaciones:'
          />
          <CustomTextArea
            handleForm={handleForm}
            name='pertinencia_medica'
            disabled={isDisabled}
            label='Pertinencia Médica:'
          />
        </div>
      </section>
      {!isDisabled && (
        <div className='flex justify-center items-center'>
          <CustomButton loading={isLoading} label='Guardar' />
        </div>
      )}
    </div>
  )
}

export default ComiteRInputs
