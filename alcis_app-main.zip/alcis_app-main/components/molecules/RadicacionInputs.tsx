'use client'

import {
  CustomMultiSelect,
  CustomTextArea,
  CustomSelect,
  CustomButton,
  CustomMultiSelectVirtual,
} from '@components/atoms'
import { useGetRadicacionInfo } from '@hooks'
import useInfoDropDown from '@hooks/useInfoDropDown'
import { CupOptionDirectus, OptionDirectus } from '@interfaces/commons'
import { RIESGOS } from '@utils/constants'
import { UUID } from 'crypto'
import { Divider } from 'primereact/divider'
import { useEffect, useState } from 'react'
import { UseFormReturn } from 'react-hook-form'
import CustomFileUpload from './CustomFileUpload'

const cupBodyTample = (cup: CupOptionDirectus) => {
  return cup ? (
    <ul className='list-none'>
      <li>
        <p className='text-wrap'>
          <strong>{cup?.codigo}</strong> - {cup?.descripcion} - <i>TR2:</i>{' '}
          <span className='scale-75 inline-block'>
            {cup?.no_tr2 ? '✅' : '❌'}
          </span>
        </p>
      </li>
    </ul>
  ) : null
}

const diagnosticoBodyTample = (diagnostico: OptionDirectus) => {
  return diagnostico ? (
    <ul className='list-none'>
      <li>
        <p className='text-wrap'>
          <strong>{diagnostico?.codigo}</strong> - {diagnostico?.descripcion}
        </p>
      </li>
    </ul>
  ) : null
}

interface RadicacionInputsProps {
  handleForm: UseFormReturn<any, any, any>
  isDisabled: boolean
  isLoading?: boolean
  qxId: UUID
  id: UUID
}

const RadicacionInputs = ({
  isDisabled,
  handleForm,
  isLoading,
  qxId,
  id,
}: RadicacionInputsProps) => {
  const { setValue } = handleForm
  const [diagnosticosInit, setDiagnosticosInit] = useState<OptionDirectus[]>([])
  const [cupsInit, setCupsInit] = useState<CupOptionDirectus[]>([])

  const {
    cups,
    loadingIpsPrimaria,
    loadingDropdown,
    diagnosticos,
    especialidades,
    medicos,
  } = useInfoDropDown(handleForm, id)

  const {
    riesgo,
    especialidad,
    medico_especialista,
    observaciones,
    diagnostico,
    cup,
    loadingRadicacion,
    dataRadicacion,
  } = useGetRadicacionInfo(qxId)

  useEffect(() => {
    if (dataRadicacion && !loadingRadicacion) {
      setValue('riesgo', riesgo)
      setValue('especialidad', especialidad)
      setValue('medico', medico_especialista)
      setValue('observaciones', observaciones)
      setDiagnosticosInit(diagnostico)
      setCupsInit(cup)
    }
  }, [dataRadicacion])

  return (
    <div className='flex flex-col w-full'>
      <CustomSelect
        handleForm={handleForm}
        name='riesgo'
        label='Riesgo'
        options={RIESGOS}
        disabled={isDisabled}
        placeholder='Seleccionar riesgo'
        required
      />
      <CustomMultiSelectVirtual
        handleForm={handleForm}
        name='diagnosticos'
        label='Diagnosticos:'
        longList={diagnosticos}
        initValue={diagnosticosInit}
        loading={!isDisabled ? loadingDropdown : false}
        optionLabel='codigo'
        itemTemplate={diagnosticoBodyTample}
        selectedItemTemplate={
          diagnosticoBodyTample || 'Seleccionar diagnostico'
        }
        placeholder='Seleccionar diagnosticos'
        maxSelectedLabels={10}
        filter
        filterBy='codigo,descripcion'
        disabled={isDisabled}
        selectedItemsLabel='{0} diagnosticos seleccionados'
        required
      />
      <CustomMultiSelectVirtual
        handleForm={handleForm}
        name='cups'
        label='CUPs:'
        longList={cups}
        initValue={cupsInit}
        loading={!isDisabled ? loadingIpsPrimaria : false}
        optionLabel='codigo'
        itemTemplate={cupBodyTample}
        selectedItemTemplate={cupBodyTample || 'Seleccionar CUPS'}
        placeholder='Seleccionar CUPS'
        maxSelectedLabels={10}
        filter
        filterBy='codigo,descripcion'
        disabled={isDisabled}
        selectedItemsLabel='{0} cups seleccionados'
        required
      />
      <CustomSelect
        handleForm={handleForm}
        name='especialidad'
        disabled={isDisabled}
        options={especialidades}
        virtualScrollerOptions={{ itemSize: 50 }}
        optionLabel='nombre'
        label='Especialidad'
        placeholder='Especialidad'
        onCustomChange={(e) => {
          setValue('especialidad', e.value, { shouldValidate: true })
        }}
        required
      />
      <CustomSelect
        handleForm={handleForm}
        name='medico'
        options={medicos}
        virtualScrollerOptions={{ itemSize: 50 }}
        disabled={isDisabled}
        optionLabel='nombre'
        placeholder='Seleccionar medico'
        label='Medico especialista'
        required
      />
      <Divider />
      <div className='flex flex-col gap-2'>
        <CustomTextArea
          disabled={isDisabled}
          handleForm={handleForm}
          name='observaciones'
          label='Observaciones:'
        />
        <CustomFileUpload qxId={qxId} />
        {!isDisabled && (
          <div className='flex justify-center items-center mt-6'>
            <CustomButton
              loading={isLoading}
              label={qxId ? 'Guardar' : 'Radicar QX'}
            />
          </div>
        )}
      </div>
    </div>
  )
}

export default RadicacionInputs
