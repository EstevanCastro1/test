'use client'

import {
  CustomButton,
  CustomCalendar,
  CustomCheckbox,
  CustomInputText,
  CustomTextArea,
} from '@components/atoms'
import { useGetRadicacionInfo, useRole } from '@hooks'
import { ROLES } from '@utils/constants'
import { UUID } from 'crypto'
import { Divider } from 'primereact/divider'
import { useEffect } from 'react'
import { UseFormReturn } from 'react-hook-form'

interface RadicacionInputsProps {
  handleForm: UseFormReturn<any, any, any>
  qxId?: UUID
  isLoading?: boolean
}

const GestorOpInputs = ({
  handleForm,
  qxId,
  isLoading,
}: RadicacionInputsProps) => {
  const { setValue } = handleForm

  const {
    trabajoSocialCirugia,
    trabajoSocialFecha,
    trabajoSocialNumero,
    trabajoSocialObservacion,
    dataRadicacion,
    loadingRadicacion,
  } = useGetRadicacionInfo(qxId)
  const { role } = useRole()

  const isComiteRegional = role === ROLES.comite_regional
  const isGestorOperativo = role === ROLES.gestor_operativo

  useEffect(() => {
    if (dataRadicacion && !loadingRadicacion) {
      setValue('numero_de_orden', trabajoSocialNumero)
      setValue('fecha_cirugia', trabajoSocialFecha)
      setValue('cirugia_ejecutada', trabajoSocialCirugia)
      setValue('observacion_gestor', trabajoSocialObservacion)
    }
  }, [dataRadicacion])

  return (
    <div className='flex flex-col justify-center items-center gap-5 [&_.p-divider-content]:custom-divider'>
      <Divider align='center'>
        <b>Gestor operativo</b>
      </Divider>
      <div className='flex flex-col w-full'>
        <div className='grid lg:grid-cols-3 w-full gap-x-5'>
          <CustomInputText
            disabled={isComiteRegional}
            handleForm={handleForm}
            name='numero_de_orden'
            label='Número de orden'
            required={isGestorOperativo}
          />
          <CustomCalendar
            handleForm={handleForm}
            disabled={isComiteRegional}
            name='fecha_cirugia'
            label='Fecha de cirugia:'
            required={isGestorOperativo}
          />
          <div className='flex items-center pt-8'>
            <CustomCheckbox
              disabled={isComiteRegional}
              name='cirugia_ejecutada'
              handleForm={handleForm}
              label='Cirugia ejecutada'
            />
          </div>
        </div>
        <CustomTextArea
          disabled={isComiteRegional}
          handleForm={handleForm}
          name='observacion_gestor'
          label='Observaciones:'
        />
      </div>
      {(isGestorOperativo || role === ROLES.admin) && (
        <CustomButton loading={isLoading} label='Guardar' />
      )}
    </div>
  )
}

export default GestorOpInputs
