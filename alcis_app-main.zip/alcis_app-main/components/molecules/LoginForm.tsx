'use client'

import Image from 'next/image'
import { InputLogin, CustomButton, PasswordInput } from '@components/atoms'
import { SubmitHandler, useForm } from 'react-hook-form'
import { useMutation } from '@apollo/client'
import { LOG_IN } from '@utils'
import { withToast } from '@hooks'
import { ReactNode } from 'react'
import { useRouter } from 'next/navigation'
import { MESSAGES, COOKIES_KEYS } from '@utils/constants'
import { setCookie } from '@utils/storage'
import { clientDirectusSystem } from '@components/templates/Providers'
import { LoginFormInput, PATHS } from '@interfaces/commons'
import { emailRegex } from '@utils/helpers'

interface Props {
  showError: (summary: ReactNode, detail: ReactNode) => void
}

const LoginForm = ({ showError }: Props) => {
  const [loginFun, { loading }] = useMutation(LOG_IN, {
    client: clientDirectusSystem,
  })
  const router = useRouter()

  const handleForm = useForm<LoginFormInput>()
  const { handleSubmit } = handleForm

  const onSubmit: SubmitHandler<LoginFormInput> = async (inputData) => {
    try {
      const res = await loginFun({
        variables: { email: inputData.email, password: inputData.password },
      })
      const dataAuth = res?.data?.auth_login

      if (dataAuth) {
        setCookie(COOKIES_KEYS.accessToken, dataAuth.access_token)
        setCookie(COOKIES_KEYS.refreshToken, dataAuth.refresh_token)
      }

      router.push(PATHS.home)
    } catch (error: any) {
      error?.message &&
        showError(error?.message, MESSAGES.ERROR.invalidCrdentials)
    }
  }

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className='flex flex-col gap-8 justify-center bg-white items-center p-10 rounded-bl-3xl rounded-tr-3xl w-full'
      style={{ boxShadow: '0px 0px 5px 2px #610C63' }}
    >
      <div className='flex justify-between items-center gap-4 w-full'>
        <h2 className='text-4xl md:text-5xl text-center font-bold text-purple'>
          Alcis
        </h2>
        <Image src='/assets/caduceo.png' alt='caduceo' width={50} height={50} />
      </div>
      <div className='flex flex-col gap-4 w-full'>
        <InputLogin
          handleForm={handleForm}
          pattern={emailRegex}
          required
          name='email'
        />
        <PasswordInput handleForm={handleForm} required name='password' />
        <div className='flex justify-center w-full'>
          <CustomButton label='Ingresar' loading={loading} />
        </div>
      </div>
    </form>
  )
}

export default withToast(LoginForm)
