'use client'

import {
  PATHS,
  PacienteRadicacion,
  RadicacionesTableProps,
  RadicacionesTable,
  ComiteStatusKey,
} from '@interfaces/commons'
import { Column } from 'primereact/column'
import { DataTable } from 'primereact/datatable'
import Image from 'next/image'
import { useParams, usePathname, useRouter } from 'next/navigation'
import { useLazyQuery } from '@apollo/client'
import { GET_RADICACION_BY_USER } from '@utils'
import {
  DEFINICION_COMITE_STATUS,
  PROCESS_STATUS,
  RIESGOS,
  ROLES,
} from '@utils/constants'
import { useEffect, useState } from 'react'
import { Button } from 'primereact/button'
import { radicacionesTableMapper } from '@utils/mapers'
import { useRadicacionContext } from '@context/RadicacionContext'
import { Tooltip } from 'primereact/tooltip'
import { useRole } from '@hooks'
import { Tag } from 'primereact/tag'

const fechaRegistroBodyTemplate = (radicacion: RadicacionesTable) => (
  <p>{radicacion?.fecha_de_registro?.formated}</p>
)

const processStatusTemplate = (radicacion: RadicacionesTable) => {
  if (radicacion?.estado_proceso === null) return
  const isEnProceso = radicacion?.estado_proceso === PROCESS_STATUS.enProceso
  const label = isEnProceso ? 'En proceso' : 'Completado'
  return (
    <Tag
      severity={isEnProceso ? 'warning' : 'success'}
      value={label}
      className='h-fit px-2 py-1 self-center'
      rounded
    />
  )
}

const comiteRegionalStatusTemplate = (radicacion: RadicacionesTable) => (
  <p>
    {radicacion?.estado_comite_regional
      ? DEFINICION_COMITE_STATUS[
          radicacion.estado_comite_regional as ComiteStatusKey
        ]
      : 'Sin definir'}
  </p>
)

const editBodyTemplate = (radicacion: RadicacionesTable) => {
  const router = useRouter()
  const path = usePathname()

  return (
    <Button
      severity='secondary'
      onClick={() => router.push(`${path}/radicacion/${radicacion.id}`)}
      type='button'
      icon='pi pi-pencil'
      size='small'
      className='!w-9 !h-9'
      rounded
    />
  )
}

const radicadoBodyTemplate = (radicacion: RadicacionesTable) => (
  <p className='w-full text-start pl-2'>
    <strong>Qx: </strong>
    {radicacion?.id.split('-')[0]}
  </p>
)

const riesgoBodyTample = (radicacion: RadicacionesTable) => {
  const riesgo = RIESGOS.find((r) => r.code === radicacion.riesgo)
  return <p>{riesgo?.label || '--'}</p>
}

const cupsBodyTample = (radicacion: RadicacionesTable) => (
  <div className='flex flex-wrap gap-x-2'>
    {radicacion?.cups.map((cup) => {
      const { id, codigo, descripcion } = cup
      const tagId = `cup-${id}`
      return (
        <div key={tagId}>
          <Tooltip
            target={`#${tagId}`}
            content={descripcion}
            position='top'
            event='hover'
            className='max-w-[30rem] text-center'
          />
          <span
            id={tagId}
            className='inline-block cursor-pointer font-semibold'
          >
            {codigo}
          </span>
        </div>
      )
    })}
  </div>
)

const diagnosticosBodyTample = (radicacion: RadicacionesTable) => (
  <div className='flex flex-wrap gap-x-2'>
    {radicacion?.diagnosticos.map((diagnostico) => {
      const { id, codigo, descripcion } = diagnostico
      const tagId = `diagnostico-${id}`
      return (
        <div key={tagId}>
          <Tooltip
            target={`#${tagId}`}
            content={descripcion}
            position='top'
            event='hover'
            className='max-w-[30rem] text-center'
          />
          <span
            id={tagId}
            className='inline-block cursor-pointer font-semibold'
          >
            {codigo}
          </span>
        </div>
      )
    })}
  </div>
)

const RadicacionesTableComp: React.FC<RadicacionesTableProps> = ({
  pacienteID,
}) => {
  const [loadingTable, setLoadingTable] = useState(true)
  const { tableRadicaciones, setTableRadicaciones } = useRadicacionContext()

  const { id } = useParams()
  const router = useRouter()
  const { role } = useRole()

  const [radicacionRefetch] = useLazyQuery(GET_RADICACION_BY_USER)

  const showButton =
    ROLES.radicador === role || ROLES.admin === role ? (
      <button
        onClick={() => router.push(`${id}${PATHS.radicacion}`)}
        className='border border-purple rounded-lg'
      >
        <Tooltip
          target={`#add-radicacion`}
          content='Agregar radicación'
          position='left'
          event='hover'
          className='max-w-[30rem] text-center -translate-x-1'
        />
        <Image
          id='add-radicacion'
          src='/assets/add.png'
          alt='add radicacion'
          height={40}
          width={40}
          className='cursor-pointer'
        />
      </button>
    ) : null

  const fetchRadicacionesByUser = async () => {
    const response: any = await radicacionRefetch({
      variables: { id: pacienteID },
    })

    const radicacionesTyped = response?.data?.paciente_by_id
      ?.paciente_radicacion as PacienteRadicacion[]

    const publishedRadicaciones = radicacionesTyped?.filter(
      (pr) => pr.radicacion_id !== null,
    )

    if (publishedRadicaciones?.length > 0) {
      const radicaciones = radicacionesTableMapper(publishedRadicaciones)
      setTableRadicaciones(radicaciones)
      setLoadingTable(response.loading)
    }
  }

  useEffect(() => {
    fetchRadicacionesByUser()
    setLoadingTable(false)
  }, [])

  return (
    <div className='flex flex-col justify-center gap-3 w-full'>
      <section className='flex justify-between items-center'>
        <span className='text-xl font-semibold text-purple'>Radicaciones</span>
        {showButton}
      </section>
      <DataTable
        value={tableRadicaciones}
        size='small'
        emptyMessage='No se encontraron radicaciones'
        sortOrder={-1}
        sortField='fecha_de_registro.timestamp'
        style={{ width: '100%' }}
        className='custom-table'
        paginator
        rows={5}
        rowsPerPageOptions={[5, 10, 25, 50]}
        loading={loadingTable}
      >
        <Column
          field='id'
          header='# Radicado'
          align={'center'}
          body={radicadoBodyTemplate}
          style={{ width: '10%', minWidth: '8rem' }}
          headerStyle={{ borderTopLeftRadius: '0.5rem' }}
        />
        <Column
          field='fecha_de_registro.timestamp'
          header='Fecha de registro'
          sortable
          align={'center'}
          body={fechaRegistroBodyTemplate}
          style={{ width: '20%', minWidth: '7rem' }}
        />
        <Column
          field='dias_de_gestion'
          align={'center'}
          header='Dias de gestión'
          style={{ width: '10%', minWidth: '5rem' }}
        />
        <Column
          field='riesgo'
          header='Riesgo'
          align={'center'}
          body={riesgoBodyTample}
          style={{ width: '15%', minWidth: '6rem' }}
        />
        <Column
          field='cups'
          align={'center'}
          header='Cup(s)'
          body={cupsBodyTample}
          style={{ width: '15%', minWidth: '9rem' }}
        />
        <Column
          field='diagnosticos'
          align={'center'}
          header='Diagnóstico(s)'
          body={diagnosticosBodyTample}
          style={{ width: '15%', minWidth: '9rem' }}
        />
        <Column
          field='estado_comite_regional'
          align={'center'}
          header='Estado comite regional'
          body={comiteRegionalStatusTemplate}
          style={{ width: '10%', minWidth: '9rem' }}
        />
        <Column
          field='estado_proceso'
          align={'center'}
          header='Estado'
          body={processStatusTemplate}
          style={{ width: '10%', minWidth: '7rem' }}
        />
        <Column
          field='radicado'
          align={'center'}
          body={editBodyTemplate}
          style={{ width: '5%', minWidth: '4rem' }}
          headerStyle={{ borderTopRightRadius: '0.5rem' }}
        />
      </DataTable>
    </div>
  )
}

export default RadicacionesTableComp
