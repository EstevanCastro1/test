'use client'
import { CustomCheckbox, CustomInputText } from '@components/atoms'
import { useBasicInfoUser } from '@hooks'
import { Divider } from 'primereact/divider'
import { useEffect } from 'react'
import { UseFormReturn } from 'react-hook-form'

interface InforBasicaProps {
  handleForm: UseFormReturn<any, any, any>
  isDisabled: boolean
}

const InfoBasica = ({ handleForm, isDisabled }: InforBasicaProps) => {
  const { setValue } = handleForm

  const { dataUserBasicInfo, loadingUserBasicInfo } = useBasicInfoUser()

  useEffect(() => {
    if (dataUserBasicInfo && !loadingUserBasicInfo) {
      const {
        direccion,
        barrio,
        telefono,
        celular_1,
        celular_2,
        email,
        redes_sociales,
      } = dataUserBasicInfo.paciente[0]

      setValue('direccion', direccion)
      setValue('barrio', barrio)
      setValue('telefono', telefono)
      setValue('celular1', celular_1)
      setValue('celular2', celular_2)
      setValue('email', email)
      setValue('redesSociales', redes_sociales)
    }
  }, [dataUserBasicInfo, loadingUserBasicInfo])

  return (
    <>
      <section className='flex flex-col justify-center items-center gap-10'>
        <div className='flex sm:text-lg gap-2 font-semibold'>
          <h2>Ultimas actualizaciones:</h2>
          <span className='text-yellow'>04/04/2023</span>
        </div>
        <div className='grid md:grid-cols-4 sm:grid-cols-3 lg:grid-cols-5 gap-x-5 w-full'>
          <CustomInputText
            handleForm={handleForm}
            name='direccion'
            disabled={isDisabled}
            label='Dirección'
            required
          />
          <CustomInputText
            handleForm={handleForm}
            name='barrio'
            disabled={isDisabled}
            label='Barrio'
          />
          <CustomInputText
            handleForm={handleForm}
            name='telefono'
            disabled={isDisabled}
            label='Teléfono'
          />
          <CustomInputText
            handleForm={handleForm}
            name='celular1'
            disabled={isDisabled}
            label='Culular 1'
          />
          <CustomInputText
            handleForm={handleForm}
            name='celular2'
            disabled={isDisabled}
            label='Culular 2'
          />
          <CustomInputText
            handleForm={handleForm}
            name='email'
            disabled={isDisabled}
            label='Email'
            required
          />
          <div className='flex items-center lg:pt-8'>
            <CustomCheckbox
              disabled={isDisabled}
              name='redesSociales'
              handleForm={handleForm}
              label='Tiene redes sociales'
            />
          </div>
        </div>
      </section>
      <Divider />
    </>
  )
}

export default InfoBasica
