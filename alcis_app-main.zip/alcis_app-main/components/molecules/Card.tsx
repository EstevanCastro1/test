'use client'

import React from 'react'
import { UUID } from 'crypto'
import { useRouter } from 'next/navigation'
import { Card } from 'primereact/card'
import { classNames as cx } from 'primereact/utils'
import { PROCESS_STATUS, STATUS } from '@utils/constants'
import { Tooltip } from 'primereact/tooltip'

export interface CardProps {
  id: UUID
  title: string
  cedula: string
  status: string
  ipsPrimaria: string
  numRadicados: number
  numCompletados: number
  numEnProceso: number
  classNames?: string
}

const CardGestorOperativo: React.FC<CardProps> = ({
  title,
  cedula,
  status,
  ipsPrimaria,
  numRadicados,
  numCompletados,
  numEnProceso,
  id,
  classNames,
}) => {
  const router = useRouter()
  const enProcesoTag = `${PROCESS_STATUS.enProceso}_${cedula}`
  const completadoTag = `${PROCESS_STATUS.completado}_${cedula}`

  return (
    <Card
      onClick={() => router.push(`/paciente/${id}`)}
      className={`text-center cursor-pointer hover:scale-105 ease-out transition text-[#010101] hover:bg-[#b6bbc4c5] h-fit bg-[#B6BBC4] border-none shadow-none rounded-2xl [&_.p-card-content]:p-0 ${classNames || ''}`}
    >
      <section className='flex flex-col justify-between items-center w-52 h-60'>
        <div className='bg-white rounded-lg px-2 py-1'>
          <p
            className={cx(
              'font-extrabold',
              { 'text-green-600': status === STATUS.published },
              { 'text-red-500': status !== STATUS.published },
            )}
          >
            {status}
          </p>
        </div>
        <h1 className='font-bold text-lg'>{title}</h1>
        <div className='flex flex-col'>
          <p className='font-semibold'>{ipsPrimaria}</p>
          <p className='font-semibold'>CC.{cedula}</p>
          <h3 className='font-extrabold mt-2'>Radicaciones({numRadicados})</h3>
          <div className='flex gap-2 justify-center items-center'>
            <Tooltip
              target={`#${enProcesoTag}`}
              content='Radicaciones en proceso'
              position='bottom'
              event='hover'
              className='max-w-[30rem] text-center'
            />
            <div
              id={enProcesoTag}
              className='rounded-full min-w-8 h-6 text-xs bg-amber-500 text-white border-2 border-white flex items-center justify-center'
            >
              {numEnProceso}
            </div>
            <Tooltip
              target={`#${completadoTag}`}
              content='Radicaciones completadas'
              position='bottom'
              event='hover'
              className='max-w-[30rem] text-center'
            />
            <div
              id={completadoTag}
              className='rounded-full min-w-8 h-6 text-xs bg-green-500 text-white border-2 border-white flex items-center justify-center'
            >
              {numCompletados}
            </div>
          </div>
        </div>
      </section>
    </Card>
  )
}

export default CardGestorOperativo
