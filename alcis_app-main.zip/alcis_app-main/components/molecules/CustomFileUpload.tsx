'use client'

import {
  useDirectusFiles,
  useGetRadicacionInfo,
  useRole,
  withToast,
} from '@hooks'
import { UploadedFile } from '@interfaces/commons'
import { MAX_MB_GALLERY, ROLES } from '@utils/constants'
import { UUID } from 'crypto'
import { ReactNode, useEffect, useState } from 'react'
import { FileUpload, FileUploadHandlerEvent } from 'primereact/fileupload'
import { ItemFile, ItemFileTmp } from '@components/atoms'
import { ProgressSpinner } from 'primereact/progressspinner'
import usePatchRadicacion from '@hooks/usePatchRadicacion'
import { useRadicacionContext } from '@context/RadicacionContext'

const EmptyFilesHC = () => <p>No hay Historia(s) Clínica(s).</p>

interface FileUploadProps {
  qxId: UUID
  showSuccess: (summary: ReactNode, detail: ReactNode) => void
  showError: (summary: ReactNode, detail: ReactNode) => void
}

const CustomFileUpload = ({
  qxId,
  showSuccess,
  showError,
}: FileUploadProps) => {
  const [loading, setLoading] = useState<boolean>(false)
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([])

  const { role } = useRole()
  const { setTmpFilesToCreate, tmpFilesToCreate } = useRadicacionContext()
  const { uploadFile } = useDirectusFiles()
  const { updateUploadedFiles } = usePatchRadicacion()
  const { historiaClinicaFiles, loadingRadicacion, dataRadicacion } =
    useGetRadicacionInfo(qxId)

  const uploadFileToDirectus = async (file: File) => {
    try {
      const uploadedFile: UploadedFile = await uploadFile(
        file,
        process.env.NEXT_PUBLIC_DIRECTUS_FILES_GALLERY as UUID,
      )
      if (uploadedFile?.id) {
        const resUpdate = await updateUploadedFiles(qxId, uploadedFile.id)
        const fileRelId = resUpdate.historia_clinica.slice(-1)[0]
        setUploadedFiles((prev) => [...prev, { ...uploadedFile, fileRelId }])
        showSuccess(
          'Carga exitosa!',
          `Archivo ${uploadedFile.filename_download} cargado exitosamente.`,
        )
      }
    } catch (error: any) {
      showError(
        'Error en la carga',
        `No se pudo cargar el archivo ${file.name}. ${error.message}`,
      )
    }
  }

  const editRadicacionFiles = (event: FileUploadHandlerEvent) => {
    setLoading(true)
    const uploadFiles = event.files.map(async (file: File) => {
      await uploadFileToDirectus(file)
    })
    Promise.all(uploadFiles).then(() => {
      event.options.clear()
      setLoading(false)
    })
  }

  const createRadicacionFiles = (event: FileUploadHandlerEvent) => {
    event.files.forEach((file) => {
      setTmpFilesToCreate((prev) => {
        const filtered = prev.filter((f) => f.name !== file.name)
        return [...filtered, file]
      })
    })
    event.options.clear()
  }

  const uploadHandler = async (event: FileUploadHandlerEvent) => {
    qxId ? editRadicacionFiles(event) : createRadicacionFiles(event)
  }

  const allowUploadFile = role !== ROLES.admin && role !== ROLES.radicador

  useEffect(() => {
    if (qxId && dataRadicacion && !loadingRadicacion) {
      setUploadedFiles(historiaClinicaFiles)
    }
  }, [dataRadicacion])

  return (
    <section className='flex flex-col w-full'>
      <div className='p-4 rounded-t-lg bg-purple flex gap-4'>
        <FileUpload
          mode='basic'
          name='demo[]'
          accept='image/*,application/pdf'
          multiple
          maxFileSize={MAX_MB_GALLERY * 1000000}
          auto
          customUpload
          uploadHandler={uploadHandler}
          chooseLabel='Cargar Historia(s) Clínica(s)'
          className='[&_.p-button]:button-upload-file'
          disabled={allowUploadFile}
        />
        {loading && (
          <div className='flex gap-2 items-center'>
            <ProgressSpinner
              style={{ width: '30px', height: '30px' }}
              strokeWidth='8'
              animationDuration='1s'
              className='stroke-white'
            />
            <p className='text-white'>Actualizando...</p>
          </div>
        )}
      </div>
      <div className='p-4 bg-white border-r border-l border-b border-[#ced4da] rounded-b-lg'>
        {!qxId ? (
          tmpFilesToCreate?.length > 0 ? (
            tmpFilesToCreate.map((tmpF) => (
              <ItemFileTmp key={tmpF.name} file={tmpF} />
            ))
          ) : (
            <EmptyFilesHC />
          )
        ) : uploadedFiles?.length > 0 ? (
          uploadedFiles.map((uf) => (
            <ItemFile
              key={uf.id}
              file={uf}
              qxId={qxId}
              setLoading={setLoading}
              setUploadedFiles={setUploadedFiles}
              showSuccess={showSuccess}
              showError={showError}
              allowUploadFile={allowUploadFile}
            />
          ))
        ) : (
          <EmptyFilesHC />
        )}
      </div>
    </section>
  )
}

export default withToast(CustomFileUpload)
