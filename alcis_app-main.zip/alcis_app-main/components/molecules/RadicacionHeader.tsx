'use client'

import { useBasicInfoUser } from '@hooks'

const RadicacionHeader = () => {
  const { dataUserBasicInfo: data } = useBasicInfoUser()

  const identificacion = data?.paciente[0]?.identificacion
  const nombre_completo = data?.paciente[0]?.nombre_completo
  const ips =
    data?.paciente[0]?.paciente_ips_primaria[0]?.ips_primaria_id.nombre
  const edad = data?.paciente[0]?.edad
  const sexo = data?.paciente[0]?.sexo
  const departamento = data?.paciente[0]?.departamento
  const municipio = data?.paciente[0]?.municipio
  const fecha_nacimiento = data?.paciente[0]?.fecha_nacimiento

  return (
    <div className='flex flex-col items-center w-full mb-6'>
      <section className='flex flex-col sm:flex-row justify-center items-center gap-3 sm:gap-32 w-full'>
        <div className='flex flex-col justify-center items-center gap-4 sm:gap-6 w-full'>
          <div className='flex flex-col justify-center items-center w-full'>
            <h1 className='text-2xl sm:text-4xl font-bold text-purple text-center'>
              {nombre_completo}
            </h1>
            <h2 className='text-lg sm:text-2xl font-semibold'>
              CC. {identificacion}
            </h2>
          </div>
          <ul className='grid gap-x-10 gap-y-2 sm:grid-cols-2 lg:grid-cols-5 w-full *:li-basic-info'>
            <li>
              <span className='text-yellow font-semibold'>Edad:</span>
              <span className='text-end'>{edad} años</span>
            </li>
            <li className='lg:col-span-2'>
              <span className='text-yellow font-semibold'>Departamento:</span>
              <span className='text-end'>{departamento}</span>
            </li>
            <li className='lg:col-span-2'>
              <span className='text-yellow font-semibold'>IPS:</span>
              <span className='text-end'>{ips}</span>
            </li>
            <li>
              <span className='text-yellow font-semibold'>Sexo:</span>
              <span className='text-end'>{sexo}</span>
            </li>
            <li className='lg:col-span-2'>
              <span className='text-yellow font-semibold'>Municipio:</span>
              <span className='text-end'>{municipio}</span>
            </li>
            <li className='lg:col-span-2'>
              <span className='text-yellow font-semibold'>
                Fecha de nacimiento:
              </span>
              <span className='text-end'>{fecha_nacimiento}</span>
            </li>
          </ul>
        </div>
      </section>
    </div>
  )
}

export default RadicacionHeader
