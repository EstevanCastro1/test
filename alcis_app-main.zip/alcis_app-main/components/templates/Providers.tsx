'use client'

import {
  ApolloClient,
  ApolloLink,
  ApolloProvider,
  InMemoryCache,
  createHttpLink,
} from '@apollo/client'
import React, { ReactNode } from 'react'
import { RadicacionProvider } from '@context/RadicacionContext'
import { authLink, errorLink } from '@utils/links'

const httpLinkDirectus = createHttpLink({
  uri: `${process.env.NEXT_PUBLIC_DIRECTUS_BASE_URL}graphql`,
})

const httpLinkDirectusSystem = createHttpLink({
  uri: `${process.env.NEXT_PUBLIC_DIRECTUS_BASE_URL}graphql/system`,
})

export const clientDirectus = new ApolloClient({
  link: ApolloLink.from([errorLink, authLink, httpLinkDirectus]),
  cache: new InMemoryCache({ addTypename: false }),
})

export const clientDirectusSystem = new ApolloClient({
  link: ApolloLink.from([errorLink, authLink, httpLinkDirectusSystem]),
  cache: new InMemoryCache({ addTypename: false }),
})

interface ProvidersProps {
  children: ReactNode
}

const Providers: React.FC<ProvidersProps> = ({ children }) => {
  return (
    <ApolloProvider client={clientDirectus}>
      <RadicacionProvider>{children}</RadicacionProvider>
    </ApolloProvider>
  )
}

export default Providers
