'use client'

import { RadicacionHeader, RadicacionesTable } from '@components/molecules'
import { UUID } from 'crypto'
import { useParams } from 'next/navigation'

const Radicacion = () => {
  const { id } = useParams()

  return (
    <section className='pt-10 flex flex-col py-10 items-center w-full'>
      <RadicacionHeader />
      <RadicacionesTable pacienteID={id as UUID} />
    </section>
  )
}

export default Radicacion
