import { LoginForm } from '@components/molecules'

const Login = () => {
  return (
    <main className='flex flex-col md:flex-row px-6 md:px-10 place-content-center min-h-screen gap-14 items-center container mx-auto'>
      <section className='flex flex-col items-center gap-10 w-full'>
        <h1 className='text-5xl font-bold text-center text-purple'>
          Radicacíón Quirurgica
        </h1>
        <p className='text-[#0f0f0f] text-center hidden md:block'>
          Para bienestar ips es de suma importancia garantizar el cuidado y
          proteccion de sus usuarios, con la gestion y seguimiento oportuno de
          todos los casos quirurgicos radicados en la plataforma Alcis.
        </p>
      </section>
      <section className='flex justify-center w-full md:w-[40rem]'>
        <LoginForm />
      </section>
    </main>
  )
}

export default Login
