import { PacienteCards } from '@components/organisms'

const ComitePage = () => (
  <PacienteCards classNames='bg-[#E4C59E] text-purple hover:bg-[#e4c49ec8]' />
)

export default ComitePage
