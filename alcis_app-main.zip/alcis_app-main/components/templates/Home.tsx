'use client'

import { ROLES } from '@utils/constants'
import { useRouter } from 'next/navigation'
import { PATHS } from '@interfaces/commons'
import { useEffect } from 'react'

import { PacienteCards } from '@components/organisms'
import { useRole } from '@hooks'

const Home = () => {
  const router = useRouter()
  const { role, loadingUser } = useRole()

  useEffect(() => {
    if (role == ROLES.radicador) router.push(PATHS.radicador)
    if (role == ROLES.comite_regional) router.push(PATHS.comite)
    if (role == ROLES.gestor_operativo) router.push(PATHS.gestor_operativo)
  }, [loadingUser])

  return <PacienteCards />
}

export default Home
