import { PacienteCards } from '@components/organisms'

const RadicadorPage = () => (
  <PacienteCards classNames='bg-purple text-[#D3DEDC] hover:bg-purple-highlight' />
)

export default RadicadorPage
