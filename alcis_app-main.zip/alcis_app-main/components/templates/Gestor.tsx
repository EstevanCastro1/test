import { PacienteCards } from '@components/organisms'

const GestorPage = () => <PacienteCards />

export default GestorPage
