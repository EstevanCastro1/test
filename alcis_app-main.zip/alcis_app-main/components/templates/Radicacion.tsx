'use client'

import React, { useEffect } from 'react'
import {
  ComiteRInputs,
  GestorOpInputs,
  InfoBasica,
  RadicacionHeader,
  RadicacionInputs,
} from '@components/molecules'
import { CODES, ROLES } from '@utils/constants'
import { SubmitHandler, useForm } from 'react-hook-form'
import {
  PacienteRadicacion,
  RadicacionForm,
  UploadedFile,
} from '@interfaces/commons'
import { useDirectusFiles, useRole } from '@hooks'
import { useMutation } from '@apollo/client'
import {
  ADD_RADICACION_TO_PATIENT,
  CANT_RAD_PACIENTE,
  CREATE_RADICACION,
  UPDATE_PACIENTE,
  UPDATE_RADICACION,
} from '@utils'
import {
  radicacionMapper,
  radicacionesTableMapper,
  radicacionesTableMapperSingle,
  updatePaciente,
} from '@utils/mapers'
import { useParams } from 'next/navigation'
import { UUID } from 'crypto'
import { useRadicacionContext } from '@context/RadicacionContext'
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog'
import usePatchRadicacion from '@hooks/usePatchRadicacion'

const radicacionFormDefault: RadicacionForm = {
  direccion: '',
  barrio: '',
  telefono: '',
  celular1: '',
  celular2: '',
  email: '',
  redesSociales: false,
  riesgo: null,
  especialidad: null,
  medico: null,
  observaciones: '',
  diagnosticos: [],
  cups: [],
  proveedor: null,
  presupuesto_regional: 0,
  presupuesto_comite: 0,
  saldo_presupuesto: 0,
  definicion_comite: null,
  triage: null,
  observaciones_comite: '',
  pertinencia_medica: '',
  numero_de_orden: '',
  cirugia_ejecutada: null,
  fecha_cirugia: null,
  observacion_gestor: '',
}

const Radicacion = () => {
  const { role } = useRole()
  const { qxId, id } = useParams()
  const { uploadFile } = useDirectusFiles()
  const { updateUploadedFiles } = usePatchRadicacion()
  const {
    setTableRadicaciones,
    tableRadicaciones,
    setTmpFilesToCreate,
    tmpFilesToCreate,
  } = useRadicacionContext()

  const handleForm = useForm<RadicacionForm>({
    defaultValues: radicacionFormDefault,
  })
  const { handleSubmit, getValues } = handleForm

  const [funAddRadicacion, { loading }] = useMutation(
    ADD_RADICACION_TO_PATIENT,
    {
      onCompleted: () => {
        console.log('Radicacion creada')
      },
    },
  )

  const [funCantRadPaciente] = useMutation(CANT_RAD_PACIENTE, {
    onCompleted: () => {
      console.log('Cantidad radicaciones de Paciente actualizado')
    },
  })

  const [funCreateRadicacion, { loading: loadingCreation }] = useMutation(
    CREATE_RADICACION,
    {
      onCompleted: () => {
        console.log('Radicacion creada')
      },
    },
  )

  const [funUpdateRadicacion, { loading: loadingUpdating }] = useMutation(
    UPDATE_RADICACION,
    {
      onCompleted: () => {
        console.log('Radicacion actualizada')
      },
    },
  )

  const [funUpdatePaciente] = useMutation(UPDATE_PACIENTE, {
    onCompleted: () => {
      console.log('Paciente actualizado')
    },
  })

  const uploadFileToDirectus = async (file: File, radicacionId: UUID) => {
    try {
      const uploadedFile: UploadedFile = await uploadFile(
        file,
        process.env.NEXT_PUBLIC_DIRECTUS_FILES_GALLERY as UUID,
      )
      if (uploadedFile?.id)
        await updateUploadedFiles(radicacionId, uploadedFile.id)
    } catch (error: any) {
      console.error({ error })
    }
  }

  const uploadFilesToNewRadicacion = async (
    files: File[],
    radicacionId: UUID,
  ) => {
    const uploadFiles = files.map(async (file: File) => {
      await uploadFileToDirectus(file, radicacionId)
    })
    await Promise.all(uploadFiles)
  }

  const createRadicacion = async (data: RadicacionForm) => {
    const response = await funCreateRadicacion({
      variables: {
        radicacion_data: radicacionMapper(data),
      },
    })

    const radicacionId: UUID = response.data?.create_radicacion_item.id
    await uploadFilesToNewRadicacion(tmpFilesToCreate, radicacionId)

    const responseAdd = await funAddRadicacion({
      variables: {
        data: {
          paciente_id: { id },
          radicacion_id: { id: radicacionId },
        },
      },
    })

    const resToTable = responseAdd?.data?.create_paciente_radicacion_item
      ?.paciente_id?.paciente_radicacion as PacienteRadicacion[]

    if (response.data && responseAdd.data) {
      await funCantRadPaciente({
        variables: {
          id,
          data: {
            cantidad_radicaciones: resToTable?.length || 0,
          },
        },
      })

      const radicaciones = radicacionesTableMapper(resToTable)
      setTableRadicaciones(radicaciones)
      window.location.href = `/paciente/${id}`
    }
  }

  const editRadicacion = async (data: RadicacionForm) => {
    const responseRadicacion = await funUpdateRadicacion({
      variables: {
        radicacion_data: radicacionMapper(data),
        id: qxId,
      },
    })

    if (responseRadicacion.data) {
      const currenRadicacion = responseRadicacion?.data?.update_radicacion_item

      const currenRadicacionObj =
        radicacionesTableMapperSingle(currenRadicacion)

      const findIndex = tableRadicaciones.findIndex(
        (item) => item.id === currenRadicacionObj.id,
      )

      if (findIndex !== -1) {
        const objToTable = tableRadicaciones.with(
          findIndex,
          currenRadicacionObj,
        )
        setTableRadicaciones(objToTable)
      }
      window.location.href = `/paciente/${id}`
    }
  }

  const onSubmit: SubmitHandler<RadicacionForm> = async (data) => {
    await funUpdatePaciente({
      variables: { id: id, paciente: updatePaciente(data) },
    })
    !qxId ? await createRadicacion(data) : await editRadicacion(data)
  }

  const accept = () => {
    onSubmit(getValues())
  }

  const showConfirm =
    !qxId &&
    (role === ROLES.radicador || role === ROLES.admin) &&
    tmpFilesToCreate?.length === 0

  const confirm = () => {
    if (showConfirm) {
      confirmDialog({
        message: 'Estas seguro de no adjuntar Historia Clínica?',
        header: 'No has adjuntado HC',
        icon: 'pi pi-exclamation-triangle',
        draggable: false,
        accept,
      })
    } else {
      accept()
    }
  }

  useEffect(() => {
    return () => setTmpFilesToCreate([])
  }, [])

  return (
    <>
      {showConfirm && <ConfirmDialog />}
      <section className='flex flex-col py-10 justify-center items-center w-full'>
        <RadicacionHeader />
        <form
          id={`form_${CODES.radicacion}`}
          onSubmit={handleSubmit(confirm)}
          className='w-full'
        >
          <InfoBasica
            handleForm={handleForm}
            isDisabled={role !== ROLES.radicador && role !== ROLES.admin}
          />
          <RadicacionInputs
            qxId={qxId as UUID}
            id={id as UUID}
            handleForm={handleForm}
            isLoading={loadingCreation || loading || loadingUpdating}
            isDisabled={role !== ROLES.radicador && role !== ROLES.admin}
          />
          {role !== ROLES.radicador && (
            <ComiteRInputs
              isLoading={loadingCreation || loadingUpdating}
              qxId={qxId as UUID}
              handleForm={handleForm}
              isDisabled={
                role !== ROLES.comite_regional && role !== ROLES.admin
              }
            />
          )}
          {role !== ROLES.radicador && (
            <GestorOpInputs
              isLoading={loadingCreation || loadingUpdating}
              qxId={qxId as UUID}
              handleForm={handleForm}
            />
          )}
        </form>
      </section>
    </>
  )
}

export default Radicacion
