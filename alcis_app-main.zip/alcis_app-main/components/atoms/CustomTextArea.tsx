'use client'

import { MESSAGES } from '@utils/constants'
import { InputTextarea, InputTextareaProps } from 'primereact/inputtextarea'
import { Controller, UseFormReturn } from 'react-hook-form'
import { classNames as cx } from 'primereact/utils'
import ErrorText from './ErrorText'

interface Props extends InputTextareaProps {
  handleForm: UseFormReturn<any, any, any>
  label: string
  name: string
  required?: boolean
}

const CustomTextArea = ({
  handleForm,
  label,
  name,
  required,
  ...restProps
}: Props) => {
  if (typeof handleForm === 'undefined') {
    return
  }

  const {
    formState: { errors },
    control,
  } = handleForm

  return (
    <Controller
      name={name as any}
      control={control}
      rules={{
        required: required ? MESSAGES.ERROR.requiredField : false,
      }}
      render={({
        field: { value, name, onChange, onBlur, ref },
        fieldState: { error },
      }) => {
        return (
          <section className='w-full flex flex-col [&_.p-inputtextarea]:custom-input [&_.p-inputtext:enabled:focus]:custom-input-active'>
            <label htmlFor={name}>{label}</label>
            <InputTextarea
              {...restProps}
              id={name}
              value={value || ''}
              onChange={(e) => onChange(e.target.value)}
              ref={ref}
              onBlur={onBlur}
              className={cx({ 'p-invalid': error }, 'w-full')}
            />
            <ErrorText name={name} errors={errors} />
          </section>
        )
      }}
    />
  )
}

export default CustomTextArea
