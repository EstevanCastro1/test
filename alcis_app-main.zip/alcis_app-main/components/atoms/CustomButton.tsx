'use client'

import { Button } from 'primereact/button'

interface ButtonLoginProps {
  label: string
  loading?: boolean
}

const ButtonLogin = ({ label, loading }: ButtonLoginProps) => {
  return (
    <Button
      severity='warning'
      type='submit'
      className='font-bold flex justify-center items-center gap-2 text-white p-2 w-full md:w-fit min-w-32 border-2 border-black'
      loading={loading}
    >
      {label}
    </Button>
  )
}

export default ButtonLogin
