'use client'

import {
  MultiSelect,
  MultiSelectAllEvent,
  MultiSelectChangeEvent,
  MultiSelectProps,
} from 'primereact/multiselect'
import React, { useEffect, useState } from 'react'
import { Controller, FieldValues, UseFormReturn } from 'react-hook-form'
import { classNames as cx } from 'primereact/utils'
import { MESSAGES } from '@utils/constants'
import ErrorText from './ErrorText'

interface Props<T> extends MultiSelectProps {
  handleForm: UseFormReturn<any, any, any>
  name: string
  label: string
  longList: T[]
  initValue: T[]
  loading: boolean
  required?: boolean
}

const CustomMultiSelectVirtual = <T extends FieldValues>({
  label,
  name,
  handleForm,
  required,
  longList,
  initValue,
  loading,
  ...restProps
}: Props<T>) => {
  const {
    formState: { errors },
    setValue,
    getFieldState,
    control,
  } = handleForm

  const [selectAll, setSelectAll] = useState(false)
  const [selectedItems, setSelectedItems] = useState<T[]>([])
  const [items, setItems] = useState<T[]>([])

  useEffect(() => {
    setValue(name, selectedItems, {
      shouldValidate: getFieldState(name).isTouched,
    })
  }, [selectedItems])

  useEffect(() => {
    setItems(longList)
  }, [longList])

  useEffect(() => {
    initValue?.length > 0 && setSelectedItems(initValue)
  }, [initValue])

  return (
    <Controller
      name={name as any}
      control={control}
      rules={{
        required: required ? MESSAGES.ERROR.requiredField : false,
      }}
      render={({ field: { name, ref, onBlur }, fieldState: { error } }) => {
        return (
          <div className='flex flex-col w-full hover:[&_.p-multiselect]:custom-input-active'>
            <label htmlFor={name} className='flex items-center gap-2'>
              <p>{label}</p>
              {loading ? (
                <>
                  <i
                    className='pi pi-spin pi-spinner'
                    style={{ fontSize: '1rem' }}
                  ></i>
                  <p>Cargando opciones...</p>
                </>
              ) : (
                ''
              )}
            </label>
            <div className='flex flex-col'>
              <MultiSelect
                {...restProps}
                id={name}
                value={selectedItems}
                options={items}
                onChange={(e: MultiSelectChangeEvent) => {
                  setSelectedItems(e.value)
                  setSelectAll(e.value.length === items.length)
                }}
                selectAll={selectAll}
                onSelectAll={(e: MultiSelectAllEvent) => {
                  setSelectedItems(e.checked ? [] : items.map((item) => item))
                  setSelectAll(!e.checked)
                }}
                virtualScrollerOptions={{ itemSize: 50 }}
                ref={ref}
                onBlur={onBlur}
                className={cx(
                  '[&_.p-multiselect-label]:custom_multi_select',
                  { 'p-invalid': error },
                  { '[&_.p-dropdown-trigger]:!text-[#dc3545]': error },
                )}
              />
              <ErrorText name={name} errors={errors} />
            </div>
          </div>
        )
      }}
    />
  )
}

export default CustomMultiSelectVirtual
