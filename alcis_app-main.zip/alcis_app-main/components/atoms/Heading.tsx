import { useRole } from '@hooks'
import { ROLES } from '@utils/constants'
import Image from 'next/image'

const Heading = ({ name }: { name: string }) => {
  const { role } = useRole()

  let image = ''

  switch (role) {
    case ROLES.comite_regional:
      image = '/assets/old-paper.png'
      break
    case ROLES.gestor_operativo:
      image = '/assets/paper-scroll.png'
      break
    case ROLES.radicador:
      image = '/assets/user.png'
      break
    default:
      image = '/assets/user.png'
  }

  return (
    <div className='flex flex-col justify-center items-center font-semibold gap-4'>
      {role === ROLES.admin ? (
        <div className='flex gap-5'>
          <Image src='/assets/user.png' height={100} width={100} alt='user' />
          <Image
            src='/assets/old-paper.png'
            height={100}
            width={100}
            alt='old-paper'
          />
          <Image
            src='/assets/paper-scroll.png'
            height={100}
            width={100}
            alt='paper-scroll'
          />
        </div>
      ) : (
        <Image src={image} height={100} width={100} alt='user' />
      )}
      <h1 className='text-2xl'>{name}</h1>
    </div>
  )
}

export default Heading
