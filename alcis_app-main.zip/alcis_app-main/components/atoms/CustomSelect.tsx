'use client'

import { MESSAGES } from '@utils/constants'
import {
  Dropdown,
  DropdownChangeEvent,
  DropdownProps,
} from 'primereact/dropdown'
import { Controller, UseFormReturn } from 'react-hook-form'
import ErrorText from './ErrorText'
import { classNames as cx } from 'primereact/utils'

interface CustomSelectProps extends DropdownProps {
  handleForm: UseFormReturn<any, any, any>
  label: string
  name: string
  required?: boolean
  onCustomChange?: (e: DropdownChangeEvent) => void
}

const CustomSelect = ({
  label,
  handleForm,
  required,
  name,
  onCustomChange,
  ...restProps
}: CustomSelectProps) => {
  const {
    formState: { errors },
    control,
  } = handleForm

  return (
    <Controller
      name={name as any}
      control={control}
      rules={{
        required: required ? MESSAGES.ERROR.requiredField : false,
      }}
      render={({
        field: { value, name, ref, onBlur, onChange },
        fieldState: { error },
      }) => {
        return (
          <div className='flex flex-col justify-end lg:justify-center hover:[&_.p-dropdown]:custom-input-active'>
            <label htmlFor={name}>{label}:</label>
            <div className='flex flex-col'>
              <Dropdown
                {...restProps}
                id={name}
                focusInputRef={ref}
                onBlur={onBlur}
                value={value}
                onChange={(e) => {
                  onChange(e.value)
                  onCustomChange && onCustomChange(e)
                }}
                className={cx(
                  '[&_.p-inputtext]:p-2',
                  { 'p-invalid': error },
                  { '[&_.p-dropdown-trigger]:!text-[#dc3545]': error },
                )}
              />
              <ErrorText name={name} errors={errors} />
            </div>
          </div>
        )
      }}
    />
  )
}

export default CustomSelect
