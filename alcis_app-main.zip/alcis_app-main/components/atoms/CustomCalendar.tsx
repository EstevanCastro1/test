'use client'

import { MESSAGES } from '@utils/constants'
import { Calendar, CalendarProps } from 'primereact/calendar'
import { Controller, UseFormReturn } from 'react-hook-form'
import { classNames as cx } from 'primereact/utils'
import { addLocale } from 'primereact/api'
import ErrorText from './ErrorText'
import { localeOptions } from '@utils/settings'

const localeCode = 'es'

interface Props extends CalendarProps {
  handleForm: UseFormReturn<any, any, any>
  label: string
  name: string
  required?: boolean
}

const CustomCalendar = ({
  label,
  name,
  handleForm,
  required,
  ...restProps
}: Props) => {
  const {
    formState: { errors },
    control,
  } = handleForm

  addLocale(localeCode, localeOptions)

  return (
    <Controller
      control={control}
      name={name as any}
      rules={{
        required: required ? MESSAGES.ERROR.requiredField : false,
      }}
      render={({
        field: { value, name, ref, onBlur, onChange },
        fieldState: { error },
      }) => {
        return (
          <div className='flex flex-col [&_.p-button]:custom_calendar_button [&_.p-inputtext]:custom-input [&_.p-inputtext:enabled:focus]:custom-input-active'>
            <label htmlFor={name}>{label}</label>
            <Calendar
              {...restProps}
              id={name}
              inputId={name}
              name={name}
              value={value || null}
              locale={localeCode}
              onChange={onChange}
              ref={ref}
              onBlur={onBlur}
              showIcon
              dateFormat='dd-mm-yy'
              hourFormat='12'
              className={cx({ 'p-invalid': error }, 'h-[42px] w-full self-end')}
            />
            <ErrorText name={name} errors={errors} />
          </div>
        )
      }}
    />
  )
}

export default CustomCalendar
