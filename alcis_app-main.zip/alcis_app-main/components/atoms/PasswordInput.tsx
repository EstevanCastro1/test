import { MESSAGES } from '@utils/constants'
import { Password, PasswordProps } from 'primereact/password'
import { Controller, UseFormReturn } from 'react-hook-form'
import { classNames as cx } from 'primereact/utils'
import ErrorText from './ErrorText'

interface InputPasswordProps extends PasswordProps {
  name: string
  handleForm: UseFormReturn<any, any, any>
  required?: boolean
}

const PasswordInput = ({
  name,
  handleForm,
  required,
  ...restProps
}: InputPasswordProps) => {
  const {
    formState: { errors },
    control,
  } = handleForm

  return (
    <Controller
      name={name as any}
      control={control}
      rules={{
        required: required ? MESSAGES.ERROR.requiredField : false,
      }}
      render={({
        field: { value, name, ref, onBlur, onChange },
        fieldState: { error },
      }) => {
        return (
          <div className='flex flex-col justify-end gap-1 [&_.p-inputtext]:custom-input [&_.p-inputtext:enabled:focus]:custom-input-active w-full'>
            <span className='p-float-label'>
              <Password
                {...restProps}
                id={name}
                inputId={name}
                onChange={(e) => onChange(e.target.value)}
                onBlur={(e) => {
                  onBlur()
                  onChange(e.target.value)
                }}
                ref={ref}
                value={value || ''}
                className={cx(
                  '[&_i]:-translate-y-1.5 w-full',
                  { 'p-invalid': error },
                  { '[&_.p-dropdown-trigger]:!text-[#dc3545]': error },
                )}
                feedback={false}
                toggleMask
              />
              <label>Password</label>
            </span>
            <ErrorText name={name} errors={errors} />
          </div>
        )
      }}
    />
  )
}

export default PasswordInput
