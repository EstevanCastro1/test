'use client'

import {
  TriStateCheckbox,
  TriStateCheckboxProps,
} from 'primereact/tristatecheckbox'
import { MESSAGES } from '@utils/constants'
import { Controller, UseFormReturn } from 'react-hook-form'
import { classNames as cx } from 'primereact/utils'
import ErrorText from './ErrorText'

interface Props extends TriStateCheckboxProps {
  handleForm: UseFormReturn<any, any, any>
  label: string
  name: string
  required?: boolean
}

const CustomCheckbox = ({
  label,
  required,
  name,
  handleForm,
  ...restProps
}: Props) => {
  const {
    formState: { errors },
    control,
  } = handleForm

  return (
    <Controller
      name={name as any}
      control={control}
      rules={{
        required: required ? MESSAGES.ERROR.requiredField : false,
      }}
      render={({
        field: { value, name, ref, onChange },
        fieldState: { error },
      }) => (
        <div className='flex flex-col gap-1 w-full'>
          <div className='flex items-center gap-2 w-full'>
            <TriStateCheckbox
              {...restProps}
              id={name}
              value={value}
              ref={ref}
              onChange={onChange}
              className={cx({ 'p-invalid': error })}
            />
            <label htmlFor={name}>{label}</label>
          </div>
          <ErrorText name={name} errors={errors} />
        </div>
      )}
    />
  )
}

export default CustomCheckbox
