import { UploadedFile } from '@interfaces/commons'
import { Image } from 'primereact/image'
import { Button } from 'primereact/button'
import { generateURLAssetsWithToken } from '@utils/url-access-token'
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog'
import { Dispatch, ReactNode, SetStateAction } from 'react'
import usePatchRadicacion from '@hooks/usePatchRadicacion'
import { UUID } from 'crypto'
import { useDirectusFiles } from '@hooks'
import { downloadFileFromDirectus } from '@utils/api'

interface ItemFileProps {
  file: UploadedFile
  qxId: UUID
  allowUploadFile: boolean
  setLoading: Dispatch<SetStateAction<boolean>>
  setUploadedFiles: Dispatch<SetStateAction<UploadedFile[]>>
  showSuccess: (summary: ReactNode, detail: ReactNode) => void
  showError: (summary: ReactNode, detail: ReactNode) => void
}

const ItemFile = ({
  file,
  qxId,
  allowUploadFile,
  setLoading,
  setUploadedFiles,
  showSuccess,
  showError,
}: ItemFileProps) => {
  const { id, fileRelId, filename_download, title, type } = file

  const { deleteUploadFile } = usePatchRadicacion()
  const { deleteFile } = useDirectusFiles()

  const deleteHCFile = async () => {
    setLoading(true)
    try {
      const resDeleted = await deleteUploadFile(qxId, fileRelId)
      if (resDeleted) {
        await deleteFile(id)
        setUploadedFiles((prev) => prev.filter((f) => f.id !== id))
        showSuccess(
          'Eliminación exitosa!',
          `Archivo ${filename_download} eliminado exitosamente.`,
        )
      }
    } catch (error: any) {
      showError(
        'Error en eliminación',
        `No se pudo eliminar el archivo ${filename_download}. ${error.message}`,
      )
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteFile = async () => {
    confirmDialog({
      tagKey: id,
      message: (
        <p>
          Está seguro de eliminar <i>'{filename_download}'</i> ?
        </p>
      ),
      header: 'Confirmación',
      icon: 'pi pi-info-circle',
      acceptClassName: 'p-button-danger',
      acceptLabel: 'Si',
      rejectLabel: 'No',
      draggable: false,
      accept: async () => {
        await deleteHCFile()
      },
    })
  }

  const handleDownloadFile = async () => {
    try {
      const response = await downloadFileFromDirectus(id)
      const url = window.URL.createObjectURL(new Blob([response]))
      const link = document.createElement('a')
      link.setAttribute('href', url)
      link.setAttribute('download', filename_download)
      document.body.appendChild(link)
      link.click()
      link.remove()
    } catch (error: any) {
      console.error('Error downloading the file:', error)
    }
  }

  return (
    <div className='flex justify-between items-center gap-2 p-2'>
      <ConfirmDialog tagKey={id} />
      <div className='flex items-center gap-2'>
        {type === 'application/pdf' ? (
          <i className='pi pi-file-pdf' style={{ fontSize: '3rem' }}></i>
        ) : (
          <Image
            src={generateURLAssetsWithToken(id, { fit: 'cover' })}
            alt={title}
            width='50'
            preview
            className='[&_img]:rounded-lg [&_img]:!min-w-12'
          />
        )}
        <p>{filename_download}</p>
      </div>
      <div className='flex gap-1'>
        {!allowUploadFile && (
          <Button
            className='w-fit p-3'
            type='button'
            severity='danger'
            text
            tooltip='Eliminar'
            tooltipOptions={{ position: 'bottom' }}
            onClick={handleDeleteFile}
          >
            <i className='pi pi-trash' style={{ fontSize: '1rem' }}></i>
          </Button>
        )}
        <Button
          className='w-fit p-3'
          type='button'
          severity='success'
          text
          tooltip='Descargar'
          tooltipOptions={{ position: 'bottom' }}
          onClick={handleDownloadFile}
        >
          <i className='pi pi-download' style={{ fontSize: '1rem' }}></i>
        </Button>
      </div>
    </div>
  )
}

export default ItemFile
