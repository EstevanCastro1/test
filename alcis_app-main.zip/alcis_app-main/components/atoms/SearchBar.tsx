import { Dispatch, SetStateAction } from 'react'

interface SearchBarProps {
  setSearch: Dispatch<SetStateAction<string>>
}

const SearchBar = ({ setSearch }: SearchBarProps) => (
  <div className='flex items-center gap-2'>
    <input
      type='text'
      onChange={(e) => setSearch(e.target.value)}
      placeholder='Buscar'
      className='border-2  border-purple outline-none text-center p-1 w-60 sm:w-80 rounded-l-lg'
    />
    <i
      className='pi pi-search text-[#ff5100d1]'
      style={{ fontSize: '25px' }}
    ></i>
  </div>
)

export default SearchBar
