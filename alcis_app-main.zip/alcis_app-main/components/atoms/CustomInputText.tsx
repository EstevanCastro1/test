'use client'

import { MESSAGES } from '@utils/constants'
import { InputText, InputTextProps } from 'primereact/inputtext'
import { Controller, UseFormReturn } from 'react-hook-form'
import { classNames as cx } from 'primereact/utils'
import ErrorText from './ErrorText'

type CustomInputTextProps = Omit<InputTextProps, 'pattern'>

interface Props extends CustomInputTextProps {
  handleForm: UseFormReturn<any, any, any>
  label: string
  name: string
  required?: boolean
  pattern?: RegExp
}

const CustomInputText = ({
  handleForm,
  label,
  name,
  required,
  pattern,
  ...restProps
}: Props) => {
  const {
    formState: { errors },
    control,
  } = handleForm

  return (
    <Controller
      name={name as any}
      control={control}
      rules={{
        required: required ? MESSAGES.ERROR.requiredField : false,
        pattern: pattern && {
          value: pattern,
          message: MESSAGES.ERROR.invalidFormat,
        },
      }}
      render={({
        field: { value, name, ref, onBlur, onChange },
        fieldState: { error },
      }) => {
        return (
          <div className='flex flex-col justify-end w-full [&_.p-inputtext]:custom-input [&_.p-inputtext:enabled:focus]:custom-input-active'>
            <label htmlFor={name}>{label}:</label>
            <InputText
              {...restProps}
              value={value || ''}
              onBlur={(e) => {
                onBlur()
                onChange(e.target.value)
              }}
              ref={ref}
              onChange={(e) => onChange(e.target.value)}
              id={name}
              aria-describedby='username-help'
              className={cx({ 'p-invalid': error }, 'p-2 sm:w-full')}
            />
            <ErrorText name={name} errors={errors} />
          </div>
        )
      }}
    />
  )
}

export default CustomInputText
