import { MESSAGES } from '@utils/constants'
import { InputText, InputTextProps } from 'primereact/inputtext'
import React from 'react'
import { Controller, UseFormReturn } from 'react-hook-form'
import ErrorText from './ErrorText'
import { classNames as cx } from 'primereact/utils'

type CustomInputTextProps = Omit<InputTextProps, 'pattern'>

interface InputLoginProps extends CustomInputTextProps {
  name: string
  handleForm: UseFormReturn<any, any, any>
  required?: boolean
  pattern?: RegExp
}

const InputLogin: React.FC<InputLoginProps> = ({
  name,
  pattern,
  required,
  handleForm,
  ...restProps
}) => {
  const {
    formState: { errors },
    control,
  } = handleForm

  return (
    <Controller
      name={name as any}
      control={control}
      rules={{
        required: required ? MESSAGES.ERROR.requiredField : false,
        pattern: pattern && {
          value: pattern,
          message: MESSAGES.ERROR.invalidFormat,
        },
      }}
      render={({
        field: { value, name, ref, onBlur, onChange },
        fieldState: { error },
      }) => {
        return (
          <div className='flex flex-col justify-end gap-1 w-full [&_.p-inputtext]:custom-input [&_.p-inputtext:enabled:focus]:custom-input-active'>
            <span className='p-float-label'>
              <InputText
                {...restProps}
                id={name}
                value={value || ''}
                onBlur={(e) => {
                  onBlur()
                  onChange(e.target.value)
                }}
                ref={ref}
                onChange={(e) => onChange(e.target.value)}
                className={cx(
                  { 'p-invalid': error },
                  { '[&_.p-dropdown-trigger]:!text-[#dc3545]': error },
                )}
              />
              <label>Email</label>
            </span>
            <ErrorText name={name} errors={errors} />
          </div>
        )
      }}
    />
  )
}

export default InputLogin
