'use client'

import Image from 'next/image'
import { useMutation, useQuery } from '@apollo/client'
import { clientDirectusSystem } from '@components/templates/Providers'
import { Menu, PATHS } from '@interfaces/commons'
import { GET_MENU, LOG_OUT } from '@utils'
import { COOKIES_KEYS } from '@utils/constants'
import { getCookie } from '@utils/storage'
import { useRouter } from 'next/navigation'
import { Sidebar } from 'primereact/sidebar'
import { useState } from 'react'
import { redirectToLogin } from '@utils/api'

const ButtonMenu = ({ name }: { name: string }) => {
  const [visibleRight, setVisibleRight] = useState<boolean>(false)
  const [funLogOut] = useMutation(LOG_OUT, {
    client: clientDirectusSystem,
  })

  const { data, loading } = useQuery(GET_MENU)

  const router = useRouter()

  const handleMenuSelect = async (route: string) => {
    if (route == PATHS.gestor_operativo) {
      router.push(PATHS.gestor_operativo)
      setVisibleRight((prev) => !prev)
    }

    if (route == PATHS.comite) {
      router.push(PATHS.comite)
      setVisibleRight((prev) => !prev)
    }

    if (route == PATHS.radicador) {
      router.push(PATHS.radicador)
      setVisibleRight((prev) => !prev)
    }
  }

  const handleLogOut = async () => {
    const refreshToken = getCookie(COOKIES_KEYS.refreshToken)
    await funLogOut({ variables: { refreshToken } })
    redirectToLogin()
  }

  return (
    <>
      <button
        onClick={() => setVisibleRight((prev) => !prev)}
        className='flex justify-center items-center gap-2'
      >
        <Image
          src='/assets/user.png'
          alt='user'
          width={20}
          height={20}
          className='sm:w-[30px] sm:h-[30px]'
        />
        <p className='font-semibold sm:font-bold text-purple'>{name}</p>
      </button>
      <Sidebar
        visible={visibleRight}
        position='right'
        onHide={() => setVisibleRight((prev) => !prev)}
      >
        <div className='flex flex-col justify-between items-center h-full'>
          <div className='flex flex-col gap-10'>
            <h2 className='text-2xl font-bold text-center text-purple'>
              {name}
            </h2>
            <ul className='flex flex-col justify-center items-center gap-8'>
              {!loading ? (
                (data as Menu)?.menu_principal.map((m) => (
                  <li key={m.id}>
                    <span
                      className='cursor-pointer text-lg hover:text-purple font-bold'
                      onClick={() => handleMenuSelect(m.ruta)}
                    >
                      {m.nombre}
                    </span>
                  </li>
                ))
              ) : (
                <p>Loading...</p>
              )}
              <li>
                <span
                  onClick={handleLogOut}
                  className='cursor-pointer font-bold'
                >
                  Salir
                </span>
              </li>
            </ul>
          </div>
          <div>
            <Image
              src='/assets/caduceo.png'
              alt='user'
              width={45}
              height={45}
              className='sm:w-[90px] self-center sm:h-[90px]'
            />
          </div>
        </div>
      </Sidebar>
    </>
  )
}

export default ButtonMenu
