import { useRadicacionContext } from '@context/RadicacionContext'
import { Button } from 'primereact/button'
import { Image } from 'primereact/image'

interface Props {
  file: File & { objectURL?: string }
}

const ItemFileTmp = ({ file }: Props) => {
  const { type, name, objectURL } = file

  const { setTmpFilesToCreate } = useRadicacionContext()

  const handleDeleteFile = () => {
    setTmpFilesToCreate((prev) => prev.filter((f) => f.name !== name))
  }

  return (
    <div className='flex justify-between items-center gap-2 p-2'>
      <div className='flex items-center gap-2'>
        {type === 'application/pdf' ? (
          <i className='pi pi-file-pdf' style={{ fontSize: '3rem' }}></i>
        ) : (
          <Image
            src={objectURL ?? '#'}
            alt={name}
            width='50'
            preview
            className='[&_img]:rounded-lg [&_img]:!min-w-12'
          />
        )}
        <p>{name}</p>
      </div>
      <div className='flex gap-1'>
        <Button
          className='w-fit p-3'
          type='button'
          severity='danger'
          text
          tooltip='Eliminar'
          tooltipOptions={{ position: 'bottom' }}
          onClick={handleDeleteFile}
        >
          <i className='pi pi-trash' style={{ fontSize: '1rem' }}></i>
        </Button>
      </div>
    </div>
  )
}

export default ItemFileTmp
