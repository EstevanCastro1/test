'use client'

import React from 'react'
import { MultiSelect, MultiSelectProps } from 'primereact/multiselect'
import { Controller, UseFormReturn } from 'react-hook-form'
import { classNames as cx } from 'primereact/utils'

import ErrorText from './ErrorText'
import { MESSAGES } from '@utils/constants'

interface Props extends MultiSelectProps {
  handleForm: UseFormReturn<any, any, any>
  label: string
  name: string
  required?: boolean
}

const CustomMultiSelect = ({
  label,
  name,
  handleForm,
  required,
  ...restProps
}: Props) => {
  const {
    formState: { errors },
    control,
  } = handleForm

  return (
    <Controller
      name={name as any}
      control={control}
      rules={{
        required: required ? MESSAGES.ERROR.requiredField : false,
      }}
      render={({
        field: { value, name, onChange, ref, onBlur },
        fieldState: { error },
      }) => {
        return (
          <div className='flex flex-col w-full hover:[&_.p-multiselect]:custom-input-active'>
            <label htmlFor={name}>{label}</label>
            <div className='flex flex-col'>
              <MultiSelect
                {...restProps}
                id={name}
                value={value}
                onChange={(e) => onChange(e.value)}
                ref={ref}
                onBlur={onBlur}
                className={cx(
                  '[&_.p-multiselect-label]:custom_multi_select',
                  { 'p-invalid': error },
                  { '[&_.p-dropdown-trigger]:!text-[#dc3545]': error },
                )}
              />
              <ErrorText name={name} errors={errors} />
            </div>
          </div>
        )
      }}
    />
  )
}

export default CustomMultiSelect
