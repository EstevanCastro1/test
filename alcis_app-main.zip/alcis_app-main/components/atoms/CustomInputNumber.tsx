'use client'

import { MESSAGES } from '@utils/constants'
import { Controller, UseFormReturn } from 'react-hook-form'
import ErrorText from './ErrorText'
import { InputNumber, InputNumberProps } from 'primereact/inputnumber'

type CustomInputNumberProps = Omit<InputNumberProps, 'pattern'>

interface Props extends CustomInputNumberProps {
  handleForm: UseFormReturn<any, any, any>
  label: string
  name: string
  required?: boolean
  pattern?: RegExp
}

const CustomInputNumber = ({
  handleForm,
  label,
  name,
  required,
  pattern,
  ...restProps
}: Props) => {
  const {
    formState: { errors },
    control,
  } = handleForm

  return (
    <Controller
      name={name as any}
      control={control}
      rules={{
        required: required ? MESSAGES.ERROR.requiredField : false,
        pattern: pattern && {
          value: pattern,
          message: MESSAGES.ERROR.invalidFormat,
        },
      }}
      render={({ field: { value, name, ref, onBlur, onChange } }) => {
        return (
          <div className='flex flex-col justify-end w-full [&_.p-inputtext]:custom-input [&_.p-inputtext:enabled:focus]:custom-input-active'>
            <label htmlFor={name}>{label}:</label>
            <InputNumber
              {...restProps}
              value={value || 0}
              id={name}
              inputRef={ref}
              onValueChange={(e) => onChange(e.value)}
              onBlur={(e) => {
                onBlur()
                onChange(e.target.value)
              }}
              aria-describedby='username-help'
              className='w-full h-[42px]'
            />
            <ErrorText name={name} errors={errors} />
          </div>
        )
      }}
    />
  )
}

export default CustomInputNumber
