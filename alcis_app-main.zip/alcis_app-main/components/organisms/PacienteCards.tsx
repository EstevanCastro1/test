'use client'

import { useQuery } from '@apollo/client'
import { SearchBar } from '@components/atoms'
import { Card } from '@components/molecules'
import { useRadicacionContext } from '@context/RadicacionContext'
import { Paciente } from '@interfaces/commons'
import { SHOW_PACIENTES_TO_CARDS } from '@utils'
import { PROCESS_STATUS, STATUS } from '@utils/constants'
import { Paginator, PaginatorPageChangeEvent } from 'primereact/paginator'
import { useEffect, useState } from 'react'

const PAGE_ZISE = 12

const getFilterObject = function getFilterObject(search: string) {
  const statusObj = {
    status: {
      _eq: STATUS.published,
    },
  }

  const objectSearch = {
    ...statusObj,
    _or: [
      { nombre_completo: { _icontains: search } },
      { identificacion: { _icontains: search } },
      {
        paciente_ips_primaria: {
          ips_primaria_id: { nombre: { _icontains: search } },
        },
      },
    ],
  }

  return !!search ? objectSearch : statusObj
}

const PacienteCards = ({ classNames }: { classNames?: string }) => {
  const [page, setPage] = useState(0)
  const [search, setSearch] = useState('' as string)
  const [rows, setRows] = useState<number>(1)
  const { setTableRadicaciones } = useRadicacionContext()

  const { data, loading } = useQuery(SHOW_PACIENTES_TO_CARDS, {
    variables: {
      limit: PAGE_ZISE,
      offset: page * PAGE_ZISE,
      filter: getFilterObject(search),
    },
  })

  const onPageChange = (event: PaginatorPageChangeEvent) => {
    setPage(event.page)
    setRows(event.rows)
  }

  useEffect(() => {
    setTableRadicaciones([])
  }, [])

  return (
    <section className='py-5 flex flex-col items-center justify-center gap-4 w-full'>
      <SearchBar setSearch={setSearch} />
      <div className='flex flex-col gap-4 flex-grow flex-wrap justify-center items-center w-full'>
        {!loading && data ? (
          <>
            <section className='flex flex-wrap justify-center gap-4 grow w-full'>
              {data?.paciente?.map((data: Paciente) => {
                const radicados = data?.paciente_radicacion.filter(
                  (pr) => pr.radicacion_id !== null,
                )
                const numCompletados = radicados.filter(
                  (pr) =>
                    pr.radicacion_id.process_status ===
                    PROCESS_STATUS.completado,
                ).length
                const numEnProceso = radicados.filter(
                  (pr) =>
                    pr.radicacion_id.process_status ===
                    PROCESS_STATUS.enProceso,
                ).length
                return (
                  <Card
                    id={data.id}
                    key={data.id}
                    status={data.status}
                    ipsPrimaria={
                      data.paciente_ips_primaria[0]?.ips_primaria_id.nombre
                    }
                    title={data.nombre_completo}
                    cedula={data.identificacion}
                    numRadicados={radicados.length}
                    numCompletados={numCompletados}
                    numEnProceso={numEnProceso}
                    classNames={classNames}
                  />
                )
              })}
            </section>
            <Paginator
              totalRecords={data?.paciente_aggregated[0]?.count?.id / PAGE_ZISE}
              first={page}
              rows={rows}
              onPageChange={onPageChange}
              className='max-sm:[&_.p-component]:p-0 w-fit self-center'
            />
          </>
        ) : (
          <div className='flex gap-2 items-center'>
            <div className='h-5'>
              <i
                className='pi pi-spin pi-spinner'
                style={{ fontSize: '1rem' }}
              ></i>
            </div>
            <p>Cargando pacientes...</p>
          </div>
        )}
      </div>
    </section>
  )
}

export default PacienteCards
