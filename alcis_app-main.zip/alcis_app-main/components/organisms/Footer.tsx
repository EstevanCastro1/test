const Footer = () => {
  return (
    <footer className='flex sticky z-50 text-purple bottom-0 backdrop-blur-md bg-white w-full justify-center p-2 font-semibold'>
      <span>©</span>
      <p>Alcis</p>
    </footer>
  )
}

export default Footer
