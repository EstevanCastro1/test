'use client'

import React from 'react'
import { ButtonMenu } from '@components/atoms'
import { useRouter } from 'next/navigation'
import { ROLES } from '@utils/constants'
import { useRole } from '@hooks'

const Header = () => {
  const router = useRouter()
  const { role, name } = useRole()

  let heading = ''

  switch (role) {
    case ROLES.admin:
      heading = ROLES.admin
      break
    case ROLES.radicador:
      heading = ROLES.radicador
      break
    case ROLES.comite_regional:
      heading = ROLES.comite_regional
      break
    case ROLES.gestor_operativo:
      heading = ROLES.gestor_operativo
      break
    default:
      heading = ''
  }

  return (
    <header className='w-full sticky top-0 bg-white z-50 flex items-center justify-between p-2 sm:p-1 sm:px-10 flex-wrap'>
      <h1
        className='text-2xl cursor-pointer text-purple sm:text-4xl font-bold'
        onClick={() => router.push('/')}
      >
        Alcis
      </h1>
      <p className=' sm:text-2xl text-black font-semibold'>{heading}</p>
      <nav>
        <ButtonMenu name={name} />
      </nav>
    </header>
  )
}

export default Header
